"""Fail-closed additive trust status for immutable historical Run evidence."""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from datetime import UTC, datetime
from enum import StrEnum
from pathlib import Path
from typing import Any, Iterable

from crypto_lab.git_identity import require_repository_root
from crypto_lab.hashing import canonical_json_bytes, canonical_sha256
from crypto_lab.status import canonicalize_evidence_failure_codes
from crypto_lab.status import validated_failure_codes


DEFAULT_RESULT_STATUS_REFS = (
    "evidence/audit/comprehensive-remediation-001/historical-result-status.json",
    "evidence/audit/comprehensive-remediation-001/runtime-proof-supersession-status.json",
    "evidence/audit/comprehensive-remediation-001/owner-child-entrypoint-supersession-status.json",
    "evidence/audit/adversarial-remediation-002/historical-result-status.json",
    (
        "evidence/audit/adversarial-remediation-002/"
        "runtime-authority-supersession-status.json"
    ),
    (
        "evidence/audit/adversarial-remediation-002/"
        "claim-schema-supersession-status.json"
    ),
    (
        "evidence/audit/adversarial-remediation-002/"
        "repository-authority-supersession-status.json"
    ),
    (
        "evidence/audit/adversarial-remediation-002/"
        "claim-holdout-supersession-status.json"
    ),
    (
        "evidence/audit/adversarial-remediation-002/"
        "active-inventory-supersession-status.json"
    ),
    (
        "evidence/audit/adversarial-remediation-002/"
        "repository-root-supersession-status.json"
    ),
)
RESULT_STATUS_V2_SCHEMA = "historical-result-status-registry-v2"
RESULT_STATUS_V3_SCHEMA = "historical-result-status-registry-v3"
RESULT_STATUS_V4_SCHEMA = "historical-result-status-registry-v4"
RESULT_STATUS_V5_SCHEMA = "historical-result-status-registry-v5"
RESULT_STATUS_V6_SCHEMA = "historical-result-status-registry-v6"
RESULT_STATUS_V7_SCHEMA = "historical-result-status-registry-v7"
RESULT_STATUS_V8_SCHEMA = "historical-result-status-registry-v8"
RESULT_STATUS_V2_POLICY = (
    "HISTORICAL_BYTES_IMMUTABLE;NON_ACTIVE_RESULTS_INELIGIBLE;"
    "FINAL_HOLDOUT_AND_PROFITABILITY_CLAIMS_NOT_AUTHORIZED"
)
V2_EVIDENCE_FILES = ("checker.json", "evidence_manifest.json", "status.json")
V3_EVIDENCE_FILES = (
    "component_validation.json",
    "evidence_manifest.json",
    "official_seal.json",
    "runtime_identity.json",
    "source_revision.json",
    "status.json",
)
V4_EVIDENCE_FILES = V3_EVIDENCE_FILES
V5_EVIDENCE_FILES = V3_EVIDENCE_FILES
V6_EVIDENCE_FILES = V3_EVIDENCE_FILES
V7_EVIDENCE_FILES = V3_EVIDENCE_FILES
V8_EVIDENCE_FILES = V3_EVIDENCE_FILES
_SHA256 = re.compile(r"[0-9a-f]{64}\Z")
_GIT_SHA = re.compile(r"[0-9a-f]{40}\Z")
_LOGICAL_RESULT = re.compile(r"[a-z0-9]+(?:-[a-z0-9]+)*\Z")
_FINDING_ID = re.compile(r"R2-[0-9]{3}\Z")
_MARKET_PROFILES = frozenset(
    {
        "BINANCE_SPOT_CASH_LONG_ONLY",
        "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
    },
)
R2_RESULT_STATUS_AUTHORITY = "ADVERSARIAL_AUDIT_REMEDIATION_002"
R2_RUNTIME_SUPERSESSION_AUTHORITY = (
    "ADVERSARIAL_AUDIT_REMEDIATION_002_RUNTIME_SUPERSESSION"
)
R2_CLAIM_SCHEMA_SUPERSESSION_AUTHORITY = (
    "ADVERSARIAL_AUDIT_REMEDIATION_002_CLAIM_SCHEMA_SUPERSESSION"
)
R2_REPOSITORY_AUTHORITY_SUPERSESSION_AUTHORITY = (
    "ADVERSARIAL_AUDIT_REMEDIATION_002_REPOSITORY_AUTHORITY_SUPERSESSION"
)
R2_CLAIM_HOLDOUT_SUPERSESSION_AUTHORITY = (
    "ADVERSARIAL_AUDIT_REMEDIATION_002_CLAIM_HOLDOUT_SUPERSESSION"
)
R2_ACTIVE_INVENTORY_SUPERSESSION_AUTHORITY = (
    "ADVERSARIAL_AUDIT_REMEDIATION_002_ACTIVE_INVENTORY_SUPERSESSION"
)
R2_REPOSITORY_ROOT_SUPERSESSION_AUTHORITY = (
    "ADVERSARIAL_AUDIT_REMEDIATION_002_EXPLICIT_REPOSITORY_ROOT_SUPERSESSION"
)
R2_AUDITED_BASELINE_COMMIT = "b5c865c28b83526ffab38152e7e6821f39b77014"


class HistoricalRunStatus(StrEnum):
    ACTIVE = "ACTIVE"
    REVOKED = "REVOKED"
    SUPERSEDED = "SUPERSEDED"


class FinancialResultStatus(StrEnum):
    ACTIVE = "ACTIVE"
    INVALIDATED = "INVALIDATED"
    SUPERSEDED = "SUPERSEDED"


class HistoricalResultClass(StrEnum):
    CANDIDATE = "CANDIDATE"
    BENCHMARK = "BENCHMARK"
    LEGACY = "LEGACY"


class HistoricalCopyRole(StrEnum):
    PRIMARY = "PRIMARY"
    REPLAY = "REPLAY"
    LEGACY = "LEGACY"


class HistoricalStatusReason(StrEnum):
    WARMUP_SCORING_ELIGIBILITY_VIOLATION = "WARMUP_SCORING_ELIGIBILITY_VIOLATION"
    RESULT_CONTRACT_V2_SUPERSESSION = "RESULT_CONTRACT_V2_SUPERSESSION"
    RUNTIME_AUTHORITY_SUPERSESSION = "RUNTIME_AUTHORITY_SUPERSESSION"
    SCIENTIFIC_LIMITATION_SCHEMA_SUPERSESSION = (
        "SCIENTIFIC_LIMITATION_SCHEMA_SUPERSESSION"
    )
    CLAIM_HOLDOUT_SEMANTIC_SUPERSESSION = "CLAIM_HOLDOUT_SEMANTIC_SUPERSESSION"
    OFFICIAL_ACTIVE_INVENTORY_SUPERSESSION = "OFFICIAL_ACTIVE_INVENTORY_SUPERSESSION"
    EXPLICIT_REPOSITORY_ROOT_SUPERSESSION = "EXPLICIT_REPOSITORY_ROOT_SUPERSESSION"
    LEGACY_AUDIT_FINDING = "LEGACY_AUDIT_FINDING"


class ReplacementRequirement(StrEnum):
    WARMUP_SCORING_FIX_AND_V2_REBUILD = "WARMUP_SCORING_FIX_AND_V2_REBUILD"
    DATASET_RELEASE_CHECKER_RESULT_SCHEMA_V2_REBUILD = (
        "DATASET_RELEASE_CHECKER_RESULT_SCHEMA_V2_REBUILD"
    )
    FINAL_PRODUCT_RUNTIME_REBUILD = "FINAL_PRODUCT_RUNTIME_REBUILD"
    SCIENTIFIC_LIMITATION_SCHEMA_FIX_AND_REBUILD = (
        "SCIENTIFIC_LIMITATION_SCHEMA_FIX_AND_REBUILD"
    )
    CLAIM_HOLDOUT_SEMANTIC_FIX_AND_REBUILD = (
        "CLAIM_HOLDOUT_SEMANTIC_FIX_AND_REBUILD"
    )
    OFFICIAL_ACTIVE_INVENTORY_REBUILD = "OFFICIAL_ACTIVE_INVENTORY_REBUILD"
    EXPLICIT_REPOSITORY_ROOT_FIX_AND_REBUILD = (
        "EXPLICIT_REPOSITORY_ROOT_FIX_AND_REBUILD"
    )
    LEGACY_UNSPECIFIED = "LEGACY_UNSPECIFIED"


R2_EXPECTED_HISTORICAL_RESULTS: dict[str, dict[str, str]] = {
    "perpetual-benchmark": {
        "market_profile": "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
        "result_class": HistoricalResultClass.BENCHMARK.value,
        "primary_path": (
            "runs/comprehensive-audit-remediation-003-perpetual-benchmark-run-a0e2b2553ed4"
        ),
        "replay_path": (
            "runs/replays/comprehensive-audit-remediation-003-perpetual-benchmark-"
            "buy-and-hold-1x-development/comprehensive-audit-remediation-003-"
            "perpetual-benchmark-run-a0e2b2553ed4"
        ),
    },
    "perpetual-candidate-a": {
        "market_profile": "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/comprehensive-audit-remediation-003-perpetual-candidate-a-run-5b7c5dba7f8b"
        ),
        "replay_path": (
            "runs/replays/comprehensive-audit-remediation-003-perpetual-candidate-a-development/"
            "comprehensive-audit-remediation-003-perpetual-candidate-a-run-5b7c5dba7f8b"
        ),
    },
    "perpetual-candidate-b": {
        "market_profile": "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/comprehensive-audit-remediation-003-perpetual-candidate-b-run-85bb3192f559"
        ),
        "replay_path": (
            "runs/replays/comprehensive-audit-remediation-003-perpetual-candidate-b-development/"
            "comprehensive-audit-remediation-003-perpetual-candidate-b-run-85bb3192f559"
        ),
    },
    "spot-benchmark": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.BENCHMARK.value,
        "primary_path": "runs/comprehensive-audit-remediation-003-spot-benchmark-run-d3e25d52686e",
        "replay_path": (
            "runs/replays/comprehensive-audit-remediation-003-spot-benchmark-"
            "buy-and-hold-1x-development/comprehensive-audit-remediation-003-"
            "spot-benchmark-run-d3e25d52686e"
        ),
    },
    "spot-candidate-a": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": "runs/comprehensive-audit-remediation-003-spot-candidate-a-run-253086685e94",
        "replay_path": (
            "runs/replays/comprehensive-audit-remediation-003-spot-candidate-a-development/"
            "comprehensive-audit-remediation-003-spot-candidate-a-run-253086685e94"
        ),
    },
    "spot-candidate-b": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": "runs/comprehensive-audit-remediation-003-spot-candidate-b-run-736f07f7755e",
        "replay_path": (
            "runs/replays/comprehensive-audit-remediation-003-spot-candidate-b-development/"
            "comprehensive-audit-remediation-003-spot-candidate-b-run-736f07f7755e"
        ),
    },
}


R2_RUNTIME_SUPERSEDED_RESULTS: dict[str, dict[str, str]] = {
    "retry-002-spot-benchmark": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.BENCHMARK.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-002-spot-benchmark-run-7da743fdaa06"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-002-spot-benchmark-"
            "buy-and-hold-1x-development/adversarial-remediation-002-retry-002-"
            "spot-benchmark-run-7da743fdaa06"
        ),
    },
    "retry-002-spot-candidate-a": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-002-spot-candidate-a-run-e1cacf032f78"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-002-spot-candidate-a-"
            "development/adversarial-remediation-002-retry-002-spot-candidate-a-"
            "run-e1cacf032f78"
        ),
    },
    "retry-002-spot-candidate-b": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-002-spot-candidate-b-run-9bbdbc35e204"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-002-spot-candidate-b-"
            "development/adversarial-remediation-002-retry-002-spot-candidate-b-"
            "run-9bbdbc35e204"
        ),
    },
    "retry-003-spot-benchmark": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.BENCHMARK.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-003-spot-benchmark-run-f28ac747c930"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-003-spot-benchmark-"
            "buy-and-hold-1x-development/adversarial-remediation-002-retry-003-"
            "spot-benchmark-run-f28ac747c930"
        ),
    },
    "retry-004-spot-benchmark": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.BENCHMARK.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-004-spot-benchmark-run-524a71ec1f23"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-004-spot-benchmark-"
            "buy-and-hold-1x-development/adversarial-remediation-002-retry-004-"
            "spot-benchmark-run-524a71ec1f23"
        ),
    },
    "retry-005-spot-benchmark": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.BENCHMARK.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-005-spot-benchmark-run-2c31e21fea1f"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-005-spot-benchmark-"
            "buy-and-hold-1x-development/adversarial-remediation-002-retry-005-"
            "spot-benchmark-run-2c31e21fea1f"
        ),
    },
    "retry-005-spot-candidate-a": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-005-spot-candidate-a-run-c14c350c3c6c"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-005-spot-candidate-a-"
            "development/adversarial-remediation-002-retry-005-spot-candidate-a-"
            "run-c14c350c3c6c"
        ),
    },
    "retry-005-spot-candidate-b": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-005-spot-candidate-b-run-cdd40a577711"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-005-spot-candidate-b-"
            "development/adversarial-remediation-002-retry-005-spot-candidate-b-"
            "run-cdd40a577711"
        ),
    },
    "retry-005-perpetual-benchmark": {
        "market_profile": "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
        "result_class": HistoricalResultClass.BENCHMARK.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-005-perpetual-benchmark-run-"
            "2a0ab6ee5579"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-005-perpetual-benchmark-"
            "buy-and-hold-1x-development/adversarial-remediation-002-retry-005-"
            "perpetual-benchmark-run-2a0ab6ee5579"
        ),
    },
    "retry-006-spot-benchmark": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.BENCHMARK.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-006-spot-benchmark-run-9602e7984645"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-006-spot-benchmark-"
            "buy-and-hold-1x-development/adversarial-remediation-002-retry-006-"
            "spot-benchmark-run-9602e7984645"
        ),
    },
    "retry-006-spot-candidate-a": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-006-spot-candidate-a-run-1a928b3db2d3"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-006-spot-candidate-a-"
            "development/adversarial-remediation-002-retry-006-spot-candidate-a-"
            "run-1a928b3db2d3"
        ),
    },
    "retry-006-spot-candidate-b": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-006-spot-candidate-b-run-c5ea2b43962f"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-006-spot-candidate-b-"
            "development/adversarial-remediation-002-retry-006-spot-candidate-b-"
            "run-c5ea2b43962f"
        ),
    },
    "retry-007-perpetual-benchmark": {
        "market_profile": "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
        "result_class": HistoricalResultClass.BENCHMARK.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-007-perpetual-benchmark-run-"
            "df8caf74b27d"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-007-perpetual-benchmark-"
            "buy-and-hold-1x-development/adversarial-remediation-002-retry-007-"
            "perpetual-benchmark-run-df8caf74b27d"
        ),
    },
    "retry-007-spot-benchmark": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.BENCHMARK.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-007-spot-benchmark-run-46d5ef9362e7"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-007-spot-benchmark-"
            "buy-and-hold-1x-development/adversarial-remediation-002-retry-007-"
            "spot-benchmark-run-46d5ef9362e7"
        ),
    },
    "retry-007-spot-candidate-a": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-007-spot-candidate-a-run-80168115684f"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-007-spot-candidate-a-"
            "development/adversarial-remediation-002-retry-007-spot-candidate-a-"
            "run-80168115684f"
        ),
    },
    "retry-007-spot-candidate-b": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-007-spot-candidate-b-run-4a9e4ae97945"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-007-spot-candidate-b-"
            "development/adversarial-remediation-002-retry-007-spot-candidate-b-"
            "run-4a9e4ae97945"
        ),
    },
}


# Retry-015 is retained intact after the Host Acceptance/CI source closure repair.
R2_RUNTIME_SUPERSEDED_RESULTS.update({
    "retry-015-spot-benchmark": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": "BENCHMARK",
        "primary_path": "runs/adversarial-remediation-002-retry-015-spot-benchmark-run-81b0c9a95088",
        "replay_path": "runs/replays/adversarial-remediation-002-retry-015-spot-benchmark-buy-and-hold-1x-development/adversarial-remediation-002-retry-015-spot-benchmark-run-81b0c9a95088"
    },
    "retry-015-spot-candidate-a": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": "CANDIDATE",
        "primary_path": "runs/adversarial-remediation-002-retry-015-spot-candidate-a-run-a55e69cccd67",
        "replay_path": "runs/replays/adversarial-remediation-002-retry-015-spot-candidate-a-development/adversarial-remediation-002-retry-015-spot-candidate-a-run-a55e69cccd67"
    },
    "retry-015-spot-candidate-b": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": "CANDIDATE",
        "primary_path": "runs/adversarial-remediation-002-retry-015-spot-candidate-b-run-885f230b33dc",
        "replay_path": "runs/replays/adversarial-remediation-002-retry-015-spot-candidate-b-development/adversarial-remediation-002-retry-015-spot-candidate-b-run-885f230b33dc"
    },
    "retry-015-perpetual-benchmark": {
        "market_profile": "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
        "result_class": "BENCHMARK",
        "primary_path": "runs/adversarial-remediation-002-retry-015-perpetual-benchmark-run-37ac036e9f58",
        "replay_path": "runs/replays/adversarial-remediation-002-retry-015-perpetual-benchmark-buy-and-hold-1x-development/adversarial-remediation-002-retry-015-perpetual-benchmark-run-37ac036e9f58"
    },
    "retry-015-perpetual-candidate-a": {
        "market_profile": "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
        "result_class": "CANDIDATE",
        "primary_path": "runs/adversarial-remediation-002-retry-015-perpetual-candidate-a-run-89d6480c4282",
        "replay_path": "runs/replays/adversarial-remediation-002-retry-015-perpetual-candidate-a-development/adversarial-remediation-002-retry-015-perpetual-candidate-a-run-89d6480c4282"
    },
    "retry-015-perpetual-candidate-b": {
        "market_profile": "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
        "result_class": "CANDIDATE",
        "primary_path": "runs/adversarial-remediation-002-retry-015-perpetual-candidate-b-run-1b9ebe2c7557",
        "replay_path": "runs/replays/adversarial-remediation-002-retry-015-perpetual-candidate-b-development/adversarial-remediation-002-retry-015-perpetual-candidate-b-run-1b9ebe2c7557"
    }
})


# The completed retry-016 benchmark predates the pinned historical-bootstrap fix.
R2_RUNTIME_SUPERSEDED_RESULTS.update({
    "retry-016-spot-benchmark": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": "BENCHMARK",
        "primary_path": "runs/adversarial-remediation-002-retry-016-spot-benchmark-run-0897cdbb1086",
        "replay_path": "runs/replays/adversarial-remediation-002-retry-016-spot-benchmark-buy-and-hold-1x-development/adversarial-remediation-002-retry-016-spot-benchmark-run-0897cdbb1086"
    }
})


# Retry-017 is retained unchanged after the multi-boundary funding diagnostic repair.
R2_RUNTIME_SUPERSEDED_RESULTS.update({
    "retry-017-spot-benchmark": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": "BENCHMARK",
        "primary_path": "runs/adversarial-remediation-002-retry-017-spot-benchmark-run-16147e079965",
        "replay_path": "runs/replays/adversarial-remediation-002-retry-017-spot-benchmark-buy-and-hold-1x-development/adversarial-remediation-002-retry-017-spot-benchmark-run-16147e079965"
    },
    "retry-017-spot-candidate-a": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": "CANDIDATE",
        "primary_path": "runs/adversarial-remediation-002-retry-017-spot-candidate-a-run-9c834f598670",
        "replay_path": "runs/replays/adversarial-remediation-002-retry-017-spot-candidate-a-development/adversarial-remediation-002-retry-017-spot-candidate-a-run-9c834f598670"
    },
    "retry-017-spot-candidate-b": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": "CANDIDATE",
        "primary_path": "runs/adversarial-remediation-002-retry-017-spot-candidate-b-run-78a761838c6e",
        "replay_path": "runs/replays/adversarial-remediation-002-retry-017-spot-candidate-b-development/adversarial-remediation-002-retry-017-spot-candidate-b-run-78a761838c6e"
    },
    "retry-017-perpetual-benchmark": {
        "market_profile": "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
        "result_class": "BENCHMARK",
        "primary_path": "runs/adversarial-remediation-002-retry-017-perpetual-benchmark-run-0ecef1839e9e",
        "replay_path": "runs/replays/adversarial-remediation-002-retry-017-perpetual-benchmark-buy-and-hold-1x-development/adversarial-remediation-002-retry-017-perpetual-benchmark-run-0ecef1839e9e"
    },
    "retry-017-perpetual-candidate-a": {
        "market_profile": "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
        "result_class": "CANDIDATE",
        "primary_path": "runs/adversarial-remediation-002-retry-017-perpetual-candidate-a-run-55681bcb7efc",
        "replay_path": "runs/replays/adversarial-remediation-002-retry-017-perpetual-candidate-a-development/adversarial-remediation-002-retry-017-perpetual-candidate-a-run-55681bcb7efc"
    },
    "retry-017-perpetual-candidate-b": {
        "market_profile": "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
        "result_class": "CANDIDATE",
        "primary_path": "runs/adversarial-remediation-002-retry-017-perpetual-candidate-b-run-1d6744832d2c",
        "replay_path": "runs/replays/adversarial-remediation-002-retry-017-perpetual-candidate-b-development/adversarial-remediation-002-retry-017-perpetual-candidate-b-run-1d6744832d2c"
    }
})



# Preserve the four completed retry-018 pairs before event-identity/root hardening.
R2_RUNTIME_SUPERSEDED_RESULTS.update({
    "retry-018-perpetual-benchmark": {
        "market_profile": "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
        "result_class": "BENCHMARK",
        "primary_path": "runs/adversarial-remediation-002-retry-018-perpetual-benchmark-run-e6befe0c82bf",
        "replay_path": "runs/replays/adversarial-remediation-002-retry-018-perpetual-benchmark-buy-and-hold-1x-development/adversarial-remediation-002-retry-018-perpetual-benchmark-run-e6befe0c82bf"
    },
    "retry-018-spot-benchmark": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": "BENCHMARK",
        "primary_path": "runs/adversarial-remediation-002-retry-018-spot-benchmark-run-831d097d2f8f",
        "replay_path": "runs/replays/adversarial-remediation-002-retry-018-spot-benchmark-buy-and-hold-1x-development/adversarial-remediation-002-retry-018-spot-benchmark-run-831d097d2f8f"
    },
    "retry-018-spot-candidate-a": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": "CANDIDATE",
        "primary_path": "runs/adversarial-remediation-002-retry-018-spot-candidate-a-run-fe32ee3970b4",
        "replay_path": "runs/replays/adversarial-remediation-002-retry-018-spot-candidate-a-development/adversarial-remediation-002-retry-018-spot-candidate-a-run-fe32ee3970b4"
    },
    "retry-018-spot-candidate-b": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": "CANDIDATE",
        "primary_path": "runs/adversarial-remediation-002-retry-018-spot-candidate-b-run-656547f31d36",
        "replay_path": "runs/replays/adversarial-remediation-002-retry-018-spot-candidate-b-development/adversarial-remediation-002-retry-018-spot-candidate-b-run-656547f31d36"
    }
})


R2_CLAIM_SCHEMA_SUPERSEDED_RESULTS: dict[str, dict[str, str]] = {
    "retry-008-perpetual-benchmark": {
        "market_profile": "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
        "result_class": HistoricalResultClass.BENCHMARK.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-008-perpetual-benchmark-run-"
            "6252b1a621c4"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-008-perpetual-benchmark-"
            "buy-and-hold-1x-development/adversarial-remediation-002-retry-008-"
            "perpetual-benchmark-run-6252b1a621c4"
        ),
    },
    "retry-008-perpetual-candidate-a": {
        "market_profile": "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-008-perpetual-candidate-a-run-"
            "fa6092949cf3"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-008-perpetual-candidate-a-"
            "development/adversarial-remediation-002-retry-008-perpetual-candidate-a-"
            "run-fa6092949cf3"
        ),
    },
    "retry-008-perpetual-candidate-b": {
        "market_profile": "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-008-perpetual-candidate-b-run-"
            "4386ce883214"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-008-perpetual-candidate-b-"
            "development/adversarial-remediation-002-retry-008-perpetual-candidate-b-"
            "run-4386ce883214"
        ),
    },
    "retry-008-spot-benchmark": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.BENCHMARK.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-008-spot-benchmark-run-a330b33e395f"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-008-spot-benchmark-"
            "buy-and-hold-1x-development/adversarial-remediation-002-retry-008-"
            "spot-benchmark-run-a330b33e395f"
        ),
    },
    "retry-008-spot-candidate-a": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-008-spot-candidate-a-run-14716a0da267"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-008-spot-candidate-a-"
            "development/adversarial-remediation-002-retry-008-spot-candidate-a-"
            "run-14716a0da267"
        ),
    },
    "retry-008-spot-candidate-b": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-008-spot-candidate-b-run-746ec9cdc2d9"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-008-spot-candidate-b-"
            "development/adversarial-remediation-002-retry-008-spot-candidate-b-"
            "run-746ec9cdc2d9"
        ),
    },
}


R2_REPOSITORY_AUTHORITY_SUPERSEDED_RESULTS: dict[str, dict[str, str]] = {
    "retry-009-perpetual-benchmark": {
        "market_profile": "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
        "result_class": HistoricalResultClass.BENCHMARK.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-009-perpetual-benchmark-run-"
            "3187fedbd2e6"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-009-perpetual-benchmark-"
            "buy-and-hold-1x-development/adversarial-remediation-002-retry-009-"
            "perpetual-benchmark-run-3187fedbd2e6"
        ),
    },
    "retry-009-perpetual-candidate-a": {
        "market_profile": "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-009-perpetual-candidate-a-run-"
            "a0acc30dced8"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-009-perpetual-candidate-a-"
            "development/adversarial-remediation-002-retry-009-perpetual-candidate-a-"
            "run-a0acc30dced8"
        ),
    },
    "retry-009-perpetual-candidate-b": {
        "market_profile": "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-009-perpetual-candidate-b-run-"
            "815d4c2bfc7a"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-009-perpetual-candidate-b-"
            "development/adversarial-remediation-002-retry-009-perpetual-candidate-b-"
            "run-815d4c2bfc7a"
        ),
    },
    "retry-009-spot-benchmark": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.BENCHMARK.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-009-spot-benchmark-run-018e4b266152"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-009-spot-benchmark-"
            "buy-and-hold-1x-development/adversarial-remediation-002-retry-009-"
            "spot-benchmark-run-018e4b266152"
        ),
    },
    "retry-009-spot-candidate-a": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-009-spot-candidate-a-run-"
            "b1bce20cc130"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-009-spot-candidate-a-"
            "development/adversarial-remediation-002-retry-009-spot-candidate-a-"
            "run-b1bce20cc130"
        ),
    },
    "retry-009-spot-candidate-b": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-009-spot-candidate-b-run-"
            "d9ff725f8590"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-009-spot-candidate-b-"
            "development/adversarial-remediation-002-retry-009-spot-candidate-b-"
            "run-d9ff725f8590"
        ),
    },
}


R2_CLAIM_HOLDOUT_SUPERSEDED_RESULTS: dict[str, dict[str, str]] = {
    "retry-010-spot-benchmark": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.BENCHMARK.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-010-spot-benchmark-run-3963f3de97c8"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-010-spot-benchmark-"
            "buy-and-hold-1x-development/adversarial-remediation-002-retry-010-"
            "spot-benchmark-run-3963f3de97c8"
        ),
    },
    "retry-010-spot-candidate-a": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-010-spot-candidate-a-run-eb0dee924b6b"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-010-spot-candidate-a-"
            "development/adversarial-remediation-002-retry-010-spot-candidate-a-"
            "run-eb0dee924b6b"
        ),
    },
    "retry-010-spot-candidate-b": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-010-spot-candidate-b-run-e50933d46dd4"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-010-spot-candidate-b-"
            "development/adversarial-remediation-002-retry-010-spot-candidate-b-"
            "run-e50933d46dd4"
        ),
    },
}


R2_ACTIVE_INVENTORY_SUPERSEDED_RESULTS: dict[str, dict[str, str]] = {
    "retry-011-perpetual-benchmark": {
        "market_profile": "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
        "result_class": HistoricalResultClass.BENCHMARK.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-011-perpetual-benchmark-run-"
            "09eadae82221"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-011-perpetual-benchmark-"
            "buy-and-hold-1x-development/adversarial-remediation-002-retry-011-"
            "perpetual-benchmark-run-09eadae82221"
        ),
    },
    "retry-011-perpetual-candidate-a": {
        "market_profile": "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-011-perpetual-candidate-a-run-"
            "6b933ded4ae4"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-011-perpetual-candidate-a-"
            "development/adversarial-remediation-002-retry-011-perpetual-candidate-a-"
            "run-6b933ded4ae4"
        ),
    },
    "retry-011-perpetual-candidate-b": {
        "market_profile": "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-011-perpetual-candidate-b-run-"
            "77de68aaa779"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-011-perpetual-candidate-b-"
            "development/adversarial-remediation-002-retry-011-perpetual-candidate-b-"
            "run-77de68aaa779"
        ),
    },
    "retry-011-spot-benchmark": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.BENCHMARK.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-011-spot-benchmark-run-fbfa1ef39cce"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-011-spot-benchmark-"
            "buy-and-hold-1x-development/adversarial-remediation-002-retry-011-"
            "spot-benchmark-run-fbfa1ef39cce"
        ),
    },
    "retry-011-spot-candidate-a": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-011-spot-candidate-a-run-"
            "213964820a51"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-011-spot-candidate-a-"
            "development/adversarial-remediation-002-retry-011-spot-candidate-a-"
            "run-213964820a51"
        ),
    },
    "retry-011-spot-candidate-b": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-011-spot-candidate-b-run-"
            "d74d9de1e933"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-011-spot-candidate-b-"
            "development/adversarial-remediation-002-retry-011-spot-candidate-b-"
            "run-d74d9de1e933"
        ),
    },
}


R2_REPOSITORY_ROOT_SUPERSEDED_RESULTS: dict[str, dict[str, str]] = {
    "retry-012-perpetual-benchmark": {
        "market_profile": "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
        "result_class": HistoricalResultClass.BENCHMARK.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-012-perpetual-benchmark-run-"
            "81fe58a28828"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-012-perpetual-benchmark-"
            "buy-and-hold-1x-development/adversarial-remediation-002-retry-012-"
            "perpetual-benchmark-run-81fe58a28828"
        ),
    },
    "retry-012-perpetual-candidate-a": {
        "market_profile": "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-012-perpetual-candidate-a-run-"
            "306f69e74b26"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-012-perpetual-candidate-a-"
            "development/adversarial-remediation-002-retry-012-perpetual-candidate-a-"
            "run-306f69e74b26"
        ),
    },
    "retry-012-perpetual-candidate-b": {
        "market_profile": "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-012-perpetual-candidate-b-run-"
            "bd26bd68a201"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-012-perpetual-candidate-b-"
            "development/adversarial-remediation-002-retry-012-perpetual-candidate-b-"
            "run-bd26bd68a201"
        ),
    },
    "retry-012-spot-benchmark": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.BENCHMARK.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-012-spot-benchmark-run-89a146f07e52"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-012-spot-benchmark-"
            "buy-and-hold-1x-development/adversarial-remediation-002-retry-012-"
            "spot-benchmark-run-89a146f07e52"
        ),
    },
    "retry-012-spot-candidate-a": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-012-spot-candidate-a-run-"
            "db0f8a5fc93d"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-012-spot-candidate-a-"
            "development/adversarial-remediation-002-retry-012-spot-candidate-a-"
            "run-db0f8a5fc93d"
        ),
    },
    "retry-012-spot-candidate-b": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-012-spot-candidate-b-run-"
            "978d34af0dbe"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-012-spot-candidate-b-"
            "development/adversarial-remediation-002-retry-012-spot-candidate-b-"
            "run-978d34af0dbe"
        ),
    },
    "retry-013-perpetual-benchmark": {
        "market_profile": "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
        "result_class": HistoricalResultClass.BENCHMARK.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-013-perpetual-benchmark-run-"
            "509fe0e72c26"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-013-perpetual-benchmark-"
            "buy-and-hold-1x-development/adversarial-remediation-002-retry-013-"
            "perpetual-benchmark-run-509fe0e72c26"
        ),
    },
    "retry-013-perpetual-candidate-a": {
        "market_profile": "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-013-perpetual-candidate-a-run-"
            "c5aecd7ca99c"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-013-perpetual-candidate-a-"
            "development/adversarial-remediation-002-retry-013-perpetual-candidate-a-"
            "run-c5aecd7ca99c"
        ),
    },
    "retry-013-perpetual-candidate-b": {
        "market_profile": "BINANCE_USDM_LINEAR_PERPETUAL_ONE_WAY_NETTING",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-013-perpetual-candidate-b-run-"
            "d3aebef34b1f"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-013-perpetual-candidate-b-"
            "development/adversarial-remediation-002-retry-013-perpetual-candidate-b-"
            "run-d3aebef34b1f"
        ),
    },
    "retry-013-spot-benchmark": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.BENCHMARK.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-013-spot-benchmark-run-682626a9b6b2"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-013-spot-benchmark-"
            "buy-and-hold-1x-development/adversarial-remediation-002-retry-013-"
            "spot-benchmark-run-682626a9b6b2"
        ),
    },
    "retry-013-spot-candidate-a": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-013-spot-candidate-a-run-"
            "1b6fe098dd9f"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-013-spot-candidate-a-"
            "development/adversarial-remediation-002-retry-013-spot-candidate-a-"
            "run-1b6fe098dd9f"
        ),
    },
    "retry-013-spot-candidate-b": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.CANDIDATE.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-013-spot-candidate-b-run-"
            "ce61e7d7331f"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-013-spot-candidate-b-"
            "development/adversarial-remediation-002-retry-013-spot-candidate-b-"
            "run-ce61e7d7331f"
        ),
    },
    "retry-014-spot-benchmark": {
        "market_profile": "BINANCE_SPOT_CASH_LONG_ONLY",
        "result_class": HistoricalResultClass.BENCHMARK.value,
        "primary_path": (
            "runs/adversarial-remediation-002-retry-014-spot-benchmark-run-9e0a0ecf1bc8"
        ),
        "replay_path": (
            "runs/replays/adversarial-remediation-002-retry-014-spot-benchmark-"
            "buy-and-hold-1x-development/adversarial-remediation-002-retry-014-"
            "spot-benchmark-run-9e0a0ecf1bc8"
        ),
    },
}


@dataclass(frozen=True)
class HistoricalResultRecord:
    path: str
    market_profile: str
    historical_run_status: HistoricalRunStatus
    financial_result_status: FinancialResultStatus
    finding_ids: tuple[str, ...]
    current_checker_outcome: str
    current_failure_codes: tuple[str, ...]
    historical_bytes_preserved: bool
    evidence_hashes: dict[str, str]
    logical_result_id: str = "LEGACY"
    result_class: HistoricalResultClass = HistoricalResultClass.LEGACY
    copy_role: HistoricalCopyRole = HistoricalCopyRole.LEGACY
    reason_code: HistoricalStatusReason = HistoricalStatusReason.LEGACY_AUDIT_FINDING
    replacement_requirement: ReplacementRequirement = ReplacementRequirement.LEGACY_UNSPECIFIED

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "current_failure_codes",
            validated_failure_codes(
                self.current_failure_codes,
                field="historical_result.current_failure_codes",
            ),
        )


@dataclass(frozen=True)
class HistoricalResultRegistry:
    source_commit: str
    records: tuple[HistoricalResultRecord, ...]
    final_holdout_authorized: bool
    profitability_claim_authorized: bool
    registry_schema: str = "audit-historical-result-status-v1"
    registry_identity: str = "NOT_APPLICABLE"
    authority_id: str = "COMPREHENSIVE_AUDIT_REMEDIATION_001"

    def for_path(self, relative_path: str) -> HistoricalResultRecord | None:
        matches = [record for record in self.records if record.path == relative_path]
        if len(matches) > 1:
            raise ValueError(f"duplicate historical result status path: {relative_path}")
        return None if not matches else matches[0]


@dataclass(frozen=True)
class ResultStatusResolution:
    relative_path: str
    historical_run_status: HistoricalRunStatus
    financial_result_status: FinancialResultStatus
    record: HistoricalResultRecord | None
    registry_path: str | None

    @property
    def is_active(self) -> bool:
        return (
            self.historical_run_status is HistoricalRunStatus.ACTIVE
            and self.financial_result_status is FinancialResultStatus.ACTIVE
            and self.record is None
        )


class ResultNotActiveError(ValueError):
    """Raised when a consumer attempts to use a revoked or superseded result."""

    def __init__(self, resolution: ResultStatusResolution) -> None:
        self.resolution = resolution
        reason = (
            resolution.record.reason_code.value
            if resolution.record is not None
            else "UNRESOLVED_NON_ACTIVE_STATUS"
        )
        super().__init__(
            f"result is not ACTIVE: {resolution.relative_path} "
            f"status={resolution.historical_run_status.value} reason={reason}",
        )


def _strict_json(payload: bytes) -> Any:
    def pairs(values: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in values:
            if key in result:
                raise ValueError(f"duplicate JSON field: {key}")
            result[key] = value
        return result

    def invalid_constant(value: str) -> None:
        raise ValueError(f"invalid JSON constant: {value}")

    try:
        return json.loads(
            payload,
            object_pairs_hook=pairs,
            parse_constant=invalid_constant,
        )
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("historical result registry JSON is invalid") from exc


def _valid_sha256(value: Any) -> bool:
    return isinstance(value, str) and _SHA256.fullmatch(value) is not None


def _valid_git_sha(value: Any) -> bool:
    return isinstance(value, str) and _GIT_SHA.fullmatch(value) is not None


def _utc_timestamp(value: Any) -> datetime:
    if not isinstance(value, str) or not value.endswith("Z"):
        raise ValueError("historical result registry timestamp must be explicit UTC")
    try:
        result = datetime.fromisoformat(value[:-1] + "+00:00")
    except ValueError as exc:
        raise ValueError("historical result registry timestamp is invalid") from exc
    if result.tzinfo is None or result.utcoffset() != UTC.utcoffset(result):
        raise ValueError("historical result registry timestamp must use UTC")
    return result


def _safe_result_path(value: Any) -> str:
    if not isinstance(value, str) or not value or "\\" in value:
        raise ValueError("historical result path is unsafe")
    candidate = Path(value)
    if (
        candidate.is_absolute()
        or len(candidate.parts) < 2
        or candidate.parts[0] != "runs"
        or ".." in candidate.parts
        or candidate.as_posix() != value
    ):
        raise ValueError("historical result path is unsafe")
    return value


def _evidence_hashes(
    value: Any,
    *,
    expected_files: tuple[str, ...] = V2_EVIDENCE_FILES,
) -> dict[str, str]:
    if (
        not isinstance(value, dict)
        or tuple(sorted(value)) != expected_files
        or not all(_valid_sha256(item) for item in value.values())
    ):
        raise ValueError("historical result evidence hashes are invalid")
    return {name: str(value[name]) for name in expected_files}


def _load_v1_registry(value: dict[str, Any]) -> HistoricalResultRegistry:
    required_root = {
        "schema",
        "audit_id",
        "audited_baseline_commit",
        "source_commit",
        "recorded_at_utc",
        "historical_policy",
        "final_holdout_authorized",
        "profitability_claim_authorized",
        "record_count",
        "records",
        "records_identity",
    }
    if (
        set(value) != required_root
        or value.get("schema") != "audit-historical-result-status-v1"
        or value.get("audit_id") != "COMPREHENSIVE_AUDIT_REMEDIATION_001"
        or value.get("audited_baseline_commit")
        != "890b9d41cc05ff091f41c82409d196c91b86d452"
        or not isinstance(value.get("historical_policy"), str)
        or not value["historical_policy"]
        or value.get("final_holdout_authorized") is not False
        or value.get("profitability_claim_authorized") is not False
        or not _valid_git_sha(value.get("source_commit"))
    ):
        raise ValueError("historical result registry schema is invalid")
    _utc_timestamp(value.get("recorded_at_utc"))
    raw_records = value.get("records")
    if (
        not isinstance(raw_records, list)
        or value.get("record_count") != len(raw_records)
        or value.get("records_identity") != canonical_sha256(raw_records)
    ):
        raise ValueError("historical result registry identity is invalid")
    records: list[HistoricalResultRecord] = []
    seen: set[str] = set()
    expected_fields = {
        "path",
        "market_profile",
        "historical_run_status",
        "financial_result_status",
        "finding_ids",
        "current_checker_outcome",
        "current_failure_codes",
        "historical_bytes_preserved",
        "evidence_hashes",
    }
    for raw in raw_records:
        if not isinstance(raw, dict) or set(raw) != expected_fields:
            raise ValueError("historical result record must be an object")
        relative = _safe_result_path(raw.get("path"))
        if relative in seen:
            raise ValueError("historical result path is duplicated")
        seen.add(relative)
        finding_ids = raw.get("finding_ids")
        failure_codes = raw.get("current_failure_codes")
        if (
            raw.get("historical_run_status") != HistoricalRunStatus.REVOKED.value
            or raw.get("financial_result_status") != FinancialResultStatus.INVALIDATED.value
            or not isinstance(finding_ids, list)
            or not finding_ids
            or not all(isinstance(item, str) and item.startswith("F-00") for item in finding_ids)
            or not isinstance(failure_codes, list)
            or not all(isinstance(item, str) and item for item in failure_codes)
            or raw.get("historical_bytes_preserved") is not True
        ):
            raise ValueError("historical result record status is invalid")
        evidence_hashes = _evidence_hashes(raw.get("evidence_hashes"))
        canonical_failure_codes = canonicalize_evidence_failure_codes(failure_codes)
        records.append(
            HistoricalResultRecord(
                path=relative,
                market_profile=str(raw.get("market_profile")),
                historical_run_status=HistoricalRunStatus.REVOKED,
                financial_result_status=FinancialResultStatus.INVALIDATED,
                finding_ids=tuple(finding_ids),
                current_checker_outcome=str(raw.get("current_checker_outcome")),
                current_failure_codes=canonical_failure_codes,
                historical_bytes_preserved=True,
                evidence_hashes=evidence_hashes,
            ),
        )
    if not records:
        raise ValueError("historical result registry must contain records")
    return HistoricalResultRegistry(
        source_commit=str(value["source_commit"]),
        records=tuple(records),
        final_holdout_authorized=False,
        profitability_claim_authorized=False,
    )


def _v2_record(raw: Any) -> HistoricalResultRecord:
    expected_fields = {
        "copy_role",
        "evidence_hashes",
        "financial_result_status",
        "finding_ids",
        "historical_bytes_preserved",
        "historical_run_status",
        "logical_result_id",
        "market_profile",
        "path",
        "reason_code",
        "replacement_requirement",
        "result_class",
    }
    if not isinstance(raw, dict) or set(raw) != expected_fields:
        raise ValueError("v2 historical result record schema is invalid")
    relative = _safe_result_path(raw.get("path"))
    logical_result_id = raw.get("logical_result_id")
    market_profile = raw.get("market_profile")
    finding_ids = raw.get("finding_ids")
    if (
        not isinstance(logical_result_id, str)
        or _LOGICAL_RESULT.fullmatch(logical_result_id) is None
        or market_profile not in _MARKET_PROFILES
        or not isinstance(finding_ids, list)
        or not finding_ids
        or tuple(sorted(set(finding_ids))) != tuple(finding_ids)
        or not all(isinstance(item, str) and _FINDING_ID.fullmatch(item) for item in finding_ids)
        or raw.get("historical_bytes_preserved") is not True
    ):
        raise ValueError("v2 historical result record material is invalid")
    try:
        result_class = HistoricalResultClass(raw.get("result_class"))
        copy_role = HistoricalCopyRole(raw.get("copy_role"))
        run_status = HistoricalRunStatus(raw.get("historical_run_status"))
        financial_status = FinancialResultStatus(raw.get("financial_result_status"))
        reason = HistoricalStatusReason(raw.get("reason_code"))
        replacement = ReplacementRequirement(raw.get("replacement_requirement"))
    except ValueError as exc:
        raise ValueError("v2 historical result record vocabulary is invalid") from exc
    if result_class is HistoricalResultClass.CANDIDATE:
        expected = (
            HistoricalRunStatus.REVOKED,
            FinancialResultStatus.INVALIDATED,
            HistoricalStatusReason.WARMUP_SCORING_ELIGIBILITY_VIOLATION,
            ReplacementRequirement.WARMUP_SCORING_FIX_AND_V2_REBUILD,
        )
        if (
            (run_status, financial_status, reason, replacement) != expected
            or finding_ids != ["R2-001", "R2-002"]
        ):
            raise ValueError("Candidate warm-up invalidation contract is inconsistent")
    elif result_class is HistoricalResultClass.BENCHMARK:
        expected = (
            HistoricalRunStatus.SUPERSEDED,
            FinancialResultStatus.SUPERSEDED,
            HistoricalStatusReason.RESULT_CONTRACT_V2_SUPERSESSION,
            ReplacementRequirement.DATASET_RELEASE_CHECKER_RESULT_SCHEMA_V2_REBUILD,
        )
        if (
            (run_status, financial_status, reason, replacement) != expected
            or finding_ids != ["R2-002"]
        ):
            raise ValueError("Benchmark v2 supersession contract is inconsistent")
    else:
        raise ValueError("v2 registries forbid LEGACY result records")
    if copy_role not in {HistoricalCopyRole.PRIMARY, HistoricalCopyRole.REPLAY}:
        raise ValueError("v2 result copy role must be PRIMARY or REPLAY")
    return HistoricalResultRecord(
        path=relative,
        market_profile=str(market_profile),
        historical_run_status=run_status,
        financial_result_status=financial_status,
        finding_ids=tuple(finding_ids),
        current_checker_outcome="NOT_APPLICABLE",
        current_failure_codes=(),
        historical_bytes_preserved=True,
        evidence_hashes=_evidence_hashes(raw.get("evidence_hashes")),
        logical_result_id=logical_result_id,
        result_class=result_class,
        copy_role=copy_role,
        reason_code=reason,
        replacement_requirement=replacement,
    )


def _v3_record(raw: Any) -> HistoricalResultRecord:
    expected_fields = {
        "copy_role",
        "evidence_hashes",
        "financial_result_status",
        "finding_ids",
        "historical_bytes_preserved",
        "historical_run_status",
        "logical_result_id",
        "market_profile",
        "path",
        "reason_code",
        "replacement_requirement",
        "result_class",
    }
    if not isinstance(raw, dict) or set(raw) != expected_fields:
        raise ValueError("v3 historical result record schema is invalid")
    relative = _safe_result_path(raw.get("path"))
    logical_result_id = raw.get("logical_result_id")
    market_profile = raw.get("market_profile")
    if (
        not isinstance(logical_result_id, str)
        or _LOGICAL_RESULT.fullmatch(logical_result_id) is None
        or market_profile not in _MARKET_PROFILES
        or raw.get("finding_ids") != ["R2-002", "R2-007"]
        or raw.get("historical_bytes_preserved") is not True
    ):
        raise ValueError("v3 historical result record material is invalid")
    try:
        result_class = HistoricalResultClass(raw.get("result_class"))
        copy_role = HistoricalCopyRole(raw.get("copy_role"))
        run_status = HistoricalRunStatus(raw.get("historical_run_status"))
        financial_status = FinancialResultStatus(raw.get("financial_result_status"))
        reason = HistoricalStatusReason(raw.get("reason_code"))
        replacement = ReplacementRequirement(raw.get("replacement_requirement"))
    except ValueError as exc:
        raise ValueError("v3 historical result record vocabulary is invalid") from exc
    if (
        result_class not in {HistoricalResultClass.CANDIDATE, HistoricalResultClass.BENCHMARK}
        or copy_role not in {HistoricalCopyRole.PRIMARY, HistoricalCopyRole.REPLAY}
        or run_status is not HistoricalRunStatus.SUPERSEDED
        or financial_status is not FinancialResultStatus.SUPERSEDED
        or reason is not HistoricalStatusReason.RUNTIME_AUTHORITY_SUPERSESSION
        or replacement is not ReplacementRequirement.FINAL_PRODUCT_RUNTIME_REBUILD
    ):
        raise ValueError("v3 runtime supersession contract is inconsistent")
    return HistoricalResultRecord(
        path=relative,
        market_profile=str(market_profile),
        historical_run_status=run_status,
        financial_result_status=financial_status,
        finding_ids=("R2-002", "R2-007"),
        current_checker_outcome="NOT_APPLICABLE",
        current_failure_codes=(),
        historical_bytes_preserved=True,
        evidence_hashes=_evidence_hashes(
            raw.get("evidence_hashes"),
            expected_files=V3_EVIDENCE_FILES,
        ),
        logical_result_id=str(logical_result_id),
        result_class=result_class,
        copy_role=copy_role,
        reason_code=reason,
        replacement_requirement=replacement,
    )


def _v4_record(raw: Any) -> HistoricalResultRecord:
    expected_fields = {
        "copy_role",
        "evidence_hashes",
        "financial_result_status",
        "finding_ids",
        "historical_bytes_preserved",
        "historical_run_status",
        "logical_result_id",
        "market_profile",
        "path",
        "reason_code",
        "replacement_requirement",
        "result_class",
    }
    if not isinstance(raw, dict) or set(raw) != expected_fields:
        raise ValueError("v4 historical result record schema is invalid")
    relative = _safe_result_path(raw.get("path"))
    logical_result_id = raw.get("logical_result_id")
    market_profile = raw.get("market_profile")
    if (
        not isinstance(logical_result_id, str)
        or _LOGICAL_RESULT.fullmatch(logical_result_id) is None
        or market_profile not in _MARKET_PROFILES
        or raw.get("finding_ids") != ["R2-002", "R2-011"]
        or raw.get("historical_bytes_preserved") is not True
    ):
        raise ValueError("v4 historical result record material is invalid")
    try:
        result_class = HistoricalResultClass(raw.get("result_class"))
        copy_role = HistoricalCopyRole(raw.get("copy_role"))
        run_status = HistoricalRunStatus(raw.get("historical_run_status"))
        financial_status = FinancialResultStatus(raw.get("financial_result_status"))
        reason = HistoricalStatusReason(raw.get("reason_code"))
        replacement = ReplacementRequirement(raw.get("replacement_requirement"))
    except ValueError as exc:
        raise ValueError("v4 historical result record vocabulary is invalid") from exc
    if (
        result_class not in {HistoricalResultClass.CANDIDATE, HistoricalResultClass.BENCHMARK}
        or copy_role not in {HistoricalCopyRole.PRIMARY, HistoricalCopyRole.REPLAY}
        or run_status is not HistoricalRunStatus.SUPERSEDED
        or financial_status is not FinancialResultStatus.SUPERSEDED
        or reason is not HistoricalStatusReason.SCIENTIFIC_LIMITATION_SCHEMA_SUPERSESSION
        or replacement
        is not ReplacementRequirement.SCIENTIFIC_LIMITATION_SCHEMA_FIX_AND_REBUILD
    ):
        raise ValueError("v4 claim-schema supersession contract is inconsistent")
    return HistoricalResultRecord(
        path=relative,
        market_profile=str(market_profile),
        historical_run_status=run_status,
        financial_result_status=financial_status,
        finding_ids=("R2-002", "R2-011"),
        current_checker_outcome="NOT_APPLICABLE",
        current_failure_codes=(),
        historical_bytes_preserved=True,
        evidence_hashes=_evidence_hashes(
            raw.get("evidence_hashes"),
            expected_files=V4_EVIDENCE_FILES,
        ),
        logical_result_id=str(logical_result_id),
        result_class=result_class,
        copy_role=copy_role,
        reason_code=reason,
        replacement_requirement=replacement,
    )


def _v5_record(raw: Any) -> HistoricalResultRecord:
    expected_fields = {
        "copy_role",
        "evidence_hashes",
        "financial_result_status",
        "finding_ids",
        "historical_bytes_preserved",
        "historical_run_status",
        "logical_result_id",
        "market_profile",
        "path",
        "reason_code",
        "replacement_requirement",
        "result_class",
    }
    if not isinstance(raw, dict) or set(raw) != expected_fields:
        raise ValueError("v5 historical result record schema is invalid")
    relative = _safe_result_path(raw.get("path"))
    logical_result_id = raw.get("logical_result_id")
    market_profile = raw.get("market_profile")
    if (
        not isinstance(logical_result_id, str)
        or _LOGICAL_RESULT.fullmatch(logical_result_id) is None
        or market_profile not in _MARKET_PROFILES
        or raw.get("finding_ids") != ["R2-002", "R2-007"]
        or raw.get("historical_bytes_preserved") is not True
    ):
        raise ValueError("v5 historical result record material is invalid")
    try:
        result_class = HistoricalResultClass(raw.get("result_class"))
        copy_role = HistoricalCopyRole(raw.get("copy_role"))
        run_status = HistoricalRunStatus(raw.get("historical_run_status"))
        financial_status = FinancialResultStatus(raw.get("financial_result_status"))
        reason = HistoricalStatusReason(raw.get("reason_code"))
        replacement = ReplacementRequirement(raw.get("replacement_requirement"))
    except ValueError as exc:
        raise ValueError("v5 historical result record vocabulary is invalid") from exc
    if (
        result_class not in {HistoricalResultClass.CANDIDATE, HistoricalResultClass.BENCHMARK}
        or copy_role not in {HistoricalCopyRole.PRIMARY, HistoricalCopyRole.REPLAY}
        or run_status is not HistoricalRunStatus.SUPERSEDED
        or financial_status is not FinancialResultStatus.SUPERSEDED
        or reason is not HistoricalStatusReason.RUNTIME_AUTHORITY_SUPERSESSION
        or replacement is not ReplacementRequirement.FINAL_PRODUCT_RUNTIME_REBUILD
    ):
        raise ValueError("v5 repository-authority supersession contract is inconsistent")
    return HistoricalResultRecord(
        path=relative,
        market_profile=str(market_profile),
        historical_run_status=run_status,
        financial_result_status=financial_status,
        finding_ids=("R2-002", "R2-007"),
        current_checker_outcome="NOT_APPLICABLE",
        current_failure_codes=(),
        historical_bytes_preserved=True,
        evidence_hashes=_evidence_hashes(
            raw.get("evidence_hashes"),
            expected_files=V5_EVIDENCE_FILES,
        ),
        logical_result_id=str(logical_result_id),
        result_class=result_class,
        copy_role=copy_role,
        reason_code=reason,
        replacement_requirement=replacement,
    )


def _v6_record(raw: Any) -> HistoricalResultRecord:
    expected_fields = {
        "copy_role",
        "evidence_hashes",
        "financial_result_status",
        "finding_ids",
        "historical_bytes_preserved",
        "historical_run_status",
        "logical_result_id",
        "market_profile",
        "path",
        "reason_code",
        "replacement_requirement",
        "result_class",
    }
    if not isinstance(raw, dict) or set(raw) != expected_fields:
        raise ValueError("v6 historical result record schema is invalid")
    relative = _safe_result_path(raw.get("path"))
    logical_result_id = raw.get("logical_result_id")
    market_profile = raw.get("market_profile")
    if (
        not isinstance(logical_result_id, str)
        or _LOGICAL_RESULT.fullmatch(logical_result_id) is None
        or market_profile not in _MARKET_PROFILES
        or raw.get("finding_ids") != ["R2-002", "R2-011"]
        or raw.get("historical_bytes_preserved") is not True
    ):
        raise ValueError("v6 historical result record material is invalid")
    try:
        result_class = HistoricalResultClass(raw.get("result_class"))
        copy_role = HistoricalCopyRole(raw.get("copy_role"))
        run_status = HistoricalRunStatus(raw.get("historical_run_status"))
        financial_status = FinancialResultStatus(raw.get("financial_result_status"))
        reason = HistoricalStatusReason(raw.get("reason_code"))
        replacement = ReplacementRequirement(raw.get("replacement_requirement"))
    except ValueError as exc:
        raise ValueError("v6 historical result record vocabulary is invalid") from exc
    if (
        result_class not in {HistoricalResultClass.CANDIDATE, HistoricalResultClass.BENCHMARK}
        or copy_role not in {HistoricalCopyRole.PRIMARY, HistoricalCopyRole.REPLAY}
        or run_status is not HistoricalRunStatus.SUPERSEDED
        or financial_status is not FinancialResultStatus.SUPERSEDED
        or reason is not HistoricalStatusReason.CLAIM_HOLDOUT_SEMANTIC_SUPERSESSION
        or replacement
        is not ReplacementRequirement.CLAIM_HOLDOUT_SEMANTIC_FIX_AND_REBUILD
    ):
        raise ValueError("v6 claim/holdout supersession contract is inconsistent")
    return HistoricalResultRecord(
        path=relative,
        market_profile=str(market_profile),
        historical_run_status=run_status,
        financial_result_status=financial_status,
        finding_ids=("R2-002", "R2-011"),
        current_checker_outcome="NOT_APPLICABLE",
        current_failure_codes=(),
        historical_bytes_preserved=True,
        evidence_hashes=_evidence_hashes(
            raw.get("evidence_hashes"),
            expected_files=V6_EVIDENCE_FILES,
        ),
        logical_result_id=str(logical_result_id),
        result_class=result_class,
        copy_role=copy_role,
        reason_code=reason,
        replacement_requirement=replacement,
    )


def _v7_record(raw: Any) -> HistoricalResultRecord:
    expected_fields = {
        "copy_role",
        "evidence_hashes",
        "financial_result_status",
        "finding_ids",
        "historical_bytes_preserved",
        "historical_run_status",
        "logical_result_id",
        "market_profile",
        "path",
        "reason_code",
        "replacement_requirement",
        "result_class",
    }
    if not isinstance(raw, dict) or set(raw) != expected_fields:
        raise ValueError("v7 historical result record schema is invalid")
    relative = _safe_result_path(raw.get("path"))
    logical_result_id = raw.get("logical_result_id")
    market_profile = raw.get("market_profile")
    if (
        not isinstance(logical_result_id, str)
        or _LOGICAL_RESULT.fullmatch(logical_result_id) is None
        or market_profile not in _MARKET_PROFILES
        or raw.get("finding_ids") != ["R2-002"]
        or raw.get("historical_bytes_preserved") is not True
    ):
        raise ValueError("v7 historical result record material is invalid")
    try:
        result_class = HistoricalResultClass(raw.get("result_class"))
        copy_role = HistoricalCopyRole(raw.get("copy_role"))
        run_status = HistoricalRunStatus(raw.get("historical_run_status"))
        financial_status = FinancialResultStatus(raw.get("financial_result_status"))
        reason = HistoricalStatusReason(raw.get("reason_code"))
        replacement = ReplacementRequirement(raw.get("replacement_requirement"))
    except ValueError as exc:
        raise ValueError("v7 historical result record vocabulary is invalid") from exc
    if (
        result_class not in {HistoricalResultClass.CANDIDATE, HistoricalResultClass.BENCHMARK}
        or copy_role not in {HistoricalCopyRole.PRIMARY, HistoricalCopyRole.REPLAY}
        or run_status is not HistoricalRunStatus.SUPERSEDED
        or financial_status is not FinancialResultStatus.SUPERSEDED
        or reason is not HistoricalStatusReason.OFFICIAL_ACTIVE_INVENTORY_SUPERSESSION
        or replacement is not ReplacementRequirement.OFFICIAL_ACTIVE_INVENTORY_REBUILD
    ):
        raise ValueError("v7 active-inventory supersession contract is inconsistent")
    return HistoricalResultRecord(
        path=relative,
        market_profile=str(market_profile),
        historical_run_status=run_status,
        financial_result_status=financial_status,
        finding_ids=("R2-002",),
        current_checker_outcome="NOT_APPLICABLE",
        current_failure_codes=(),
        historical_bytes_preserved=True,
        evidence_hashes=_evidence_hashes(
            raw.get("evidence_hashes"),
            expected_files=V7_EVIDENCE_FILES,
        ),
        logical_result_id=str(logical_result_id),
        result_class=result_class,
        copy_role=copy_role,
        reason_code=reason,
        replacement_requirement=replacement,
    )


def _v8_record(raw: Any) -> HistoricalResultRecord:
    expected_fields = {
        "copy_role",
        "evidence_hashes",
        "financial_result_status",
        "finding_ids",
        "historical_bytes_preserved",
        "historical_run_status",
        "logical_result_id",
        "market_profile",
        "path",
        "reason_code",
        "replacement_requirement",
        "result_class",
    }
    if not isinstance(raw, dict) or set(raw) != expected_fields:
        raise ValueError("v8 historical result record schema is invalid")
    relative = _safe_result_path(raw.get("path"))
    logical_result_id = raw.get("logical_result_id")
    market_profile = raw.get("market_profile")
    if (
        not isinstance(logical_result_id, str)
        or _LOGICAL_RESULT.fullmatch(logical_result_id) is None
        or market_profile not in _MARKET_PROFILES
        or raw.get("finding_ids") != ["R2-002", "R2-007"]
        or raw.get("historical_bytes_preserved") is not True
    ):
        raise ValueError("v8 historical result record material is invalid")
    try:
        result_class = HistoricalResultClass(raw.get("result_class"))
        copy_role = HistoricalCopyRole(raw.get("copy_role"))
        run_status = HistoricalRunStatus(raw.get("historical_run_status"))
        financial_status = FinancialResultStatus(raw.get("financial_result_status"))
        reason = HistoricalStatusReason(raw.get("reason_code"))
        replacement = ReplacementRequirement(raw.get("replacement_requirement"))
    except ValueError as exc:
        raise ValueError("v8 historical result record vocabulary is invalid") from exc
    if (
        result_class not in {HistoricalResultClass.CANDIDATE, HistoricalResultClass.BENCHMARK}
        or copy_role not in {HistoricalCopyRole.PRIMARY, HistoricalCopyRole.REPLAY}
        or run_status is not HistoricalRunStatus.SUPERSEDED
        or financial_status is not FinancialResultStatus.SUPERSEDED
        or reason is not HistoricalStatusReason.EXPLICIT_REPOSITORY_ROOT_SUPERSESSION
        or replacement
        is not ReplacementRequirement.EXPLICIT_REPOSITORY_ROOT_FIX_AND_REBUILD
    ):
        raise ValueError("v8 explicit-repository-root supersession contract is inconsistent")
    return HistoricalResultRecord(
        path=relative,
        market_profile=str(market_profile),
        historical_run_status=run_status,
        financial_result_status=financial_status,
        finding_ids=("R2-002", "R2-007"),
        current_checker_outcome="NOT_APPLICABLE",
        current_failure_codes=(),
        historical_bytes_preserved=True,
        evidence_hashes=_evidence_hashes(
            raw.get("evidence_hashes"),
            expected_files=V8_EVIDENCE_FILES,
        ),
        logical_result_id=str(logical_result_id),
        result_class=result_class,
        copy_role=copy_role,
        reason_code=reason,
        replacement_requirement=replacement,
    )


def _load_v2_registry(value: dict[str, Any], payload: bytes) -> HistoricalResultRegistry:
    required_root = {
        "audited_baseline_commit",
        "authority_id",
        "final_holdout_authorized",
        "historical_policy",
        "profitability_claim_authorized",
        "record_count",
        "recorded_at_utc",
        "records",
        "records_identity",
        "registry_identity",
        "schema",
        "source_commit",
    }
    if (
        set(value) != required_root
        or value.get("schema") != RESULT_STATUS_V2_SCHEMA
        or value.get("authority_id") != R2_RESULT_STATUS_AUTHORITY
        or value.get("audited_baseline_commit") != R2_AUDITED_BASELINE_COMMIT
        or not _valid_git_sha(value.get("source_commit"))
        or value.get("historical_policy") != RESULT_STATUS_V2_POLICY
        or value.get("final_holdout_authorized") is not False
        or value.get("profitability_claim_authorized") is not False
    ):
        raise ValueError("v2 historical result registry schema is invalid")
    _utc_timestamp(value.get("recorded_at_utc"))
    raw_records = value.get("records")
    if (
        not isinstance(raw_records, list)
        or not raw_records
        or value.get("record_count") != len(raw_records)
        or value.get("records_identity") != canonical_sha256(raw_records)
    ):
        raise ValueError("v2 historical result registry records identity is invalid")
    material = dict(value)
    declared_identity = material.pop("registry_identity", None)
    if not _valid_sha256(declared_identity) or canonical_sha256(material) != declared_identity:
        raise ValueError("v2 historical result registry root identity is invalid")
    if payload != canonical_json_bytes(value) + b"\n":
        raise ValueError("v2 historical result registry bytes are not canonical")
    records = tuple(_v2_record(raw) for raw in raw_records)
    ordering = tuple(
        sorted(
            records,
            key=lambda item: (item.logical_result_id, item.copy_role.value, item.path),
        ),
    )
    if records != ordering or len({item.path for item in records}) != len(records):
        raise ValueError("v2 historical result records are unordered or duplicated")
    by_logical: dict[str, list[HistoricalResultRecord]] = {}
    for record in records:
        by_logical.setdefault(record.logical_result_id, []).append(record)
    if set(by_logical) != set(R2_EXPECTED_HISTORICAL_RESULTS) or len(records) != 12:
        raise ValueError("v2 historical result registry does not cover the exact R2-002 scope")
    for logical_result_id, pair in by_logical.items():
        if (
            {item.copy_role for item in pair}
            != {HistoricalCopyRole.PRIMARY, HistoricalCopyRole.REPLAY}
            or len(pair) != 2
        ):
            raise ValueError(f"v2 primary/replay pair is incomplete: {logical_result_id}")
        first, second = pair
        stable = lambda item: (
            item.market_profile,
            item.result_class,
            item.historical_run_status,
            item.financial_result_status,
            item.finding_ids,
            item.reason_code,
            item.replacement_requirement,
        )
        if stable(first) != stable(second):
            raise ValueError(f"v2 primary/replay statuses conflict: {logical_result_id}")
        expected_result = R2_EXPECTED_HISTORICAL_RESULTS[logical_result_id]
        actual_paths = {item.copy_role: item.path for item in pair}
        if (
            first.market_profile != expected_result["market_profile"]
            or first.result_class.value != expected_result["result_class"]
            or actual_paths[HistoricalCopyRole.PRIMARY] != expected_result["primary_path"]
            or actual_paths[HistoricalCopyRole.REPLAY] != expected_result["replay_path"]
        ):
            raise ValueError(f"v2 historical result authority scope mismatch: {logical_result_id}")
    return HistoricalResultRegistry(
        source_commit=str(value["source_commit"]),
        records=records,
        final_holdout_authorized=False,
        profitability_claim_authorized=False,
        registry_schema=RESULT_STATUS_V2_SCHEMA,
        registry_identity=str(declared_identity),
        authority_id=str(value["authority_id"]),
    )


def _load_v3_registry(value: dict[str, Any], payload: bytes) -> HistoricalResultRegistry:
    required_root = {
        "audited_baseline_commit",
        "authority_id",
        "final_holdout_authorized",
        "historical_policy",
        "profitability_claim_authorized",
        "record_count",
        "recorded_at_utc",
        "records",
        "records_identity",
        "registry_identity",
        "schema",
        "source_commit",
    }
    if (
        set(value) != required_root
        or value.get("schema") != RESULT_STATUS_V3_SCHEMA
        or value.get("authority_id") != R2_RUNTIME_SUPERSESSION_AUTHORITY
        or value.get("audited_baseline_commit") != R2_AUDITED_BASELINE_COMMIT
        or not _valid_git_sha(value.get("source_commit"))
        or value.get("historical_policy") != RESULT_STATUS_V2_POLICY
        or value.get("final_holdout_authorized") is not False
        or value.get("profitability_claim_authorized") is not False
    ):
        raise ValueError("v3 historical result registry schema is invalid")
    _utc_timestamp(value.get("recorded_at_utc"))
    raw_records = value.get("records")
    if (
        not isinstance(raw_records, list)
        or not raw_records
        or value.get("record_count") != len(raw_records)
        or value.get("records_identity") != canonical_sha256(raw_records)
    ):
        raise ValueError("v3 historical result registry records identity is invalid")
    material = dict(value)
    declared_identity = material.pop("registry_identity", None)
    if not _valid_sha256(declared_identity) or canonical_sha256(material) != declared_identity:
        raise ValueError("v3 historical result registry root identity is invalid")
    if payload != canonical_json_bytes(value) + b"\n":
        raise ValueError("v3 historical result registry bytes are not canonical")
    records = tuple(_v3_record(raw) for raw in raw_records)
    ordering = tuple(
        sorted(
            records,
            key=lambda item: (item.logical_result_id, item.copy_role.value, item.path),
        ),
    )
    if records != ordering or len({item.path for item in records}) != len(records):
        raise ValueError("v3 historical result records are unordered or duplicated")
    by_logical: dict[str, list[HistoricalResultRecord]] = {}
    for record in records:
        by_logical.setdefault(record.logical_result_id, []).append(record)
    if (
        set(by_logical) != set(R2_RUNTIME_SUPERSEDED_RESULTS)
        or len(records) != 2 * len(R2_RUNTIME_SUPERSEDED_RESULTS)
    ):
        raise ValueError("v3 registry does not cover the exact runtime-supersession scope")
    for logical_result_id, pair in by_logical.items():
        if (
            {item.copy_role for item in pair}
            != {HistoricalCopyRole.PRIMARY, HistoricalCopyRole.REPLAY}
            or len(pair) != 2
        ):
            raise ValueError(f"v3 primary/replay pair is incomplete: {logical_result_id}")
        expected = R2_RUNTIME_SUPERSEDED_RESULTS[logical_result_id]
        paths = {item.copy_role: item.path for item in pair}
        first, second = pair
        stable = lambda item: (
            item.market_profile,
            item.result_class,
            item.historical_run_status,
            item.financial_result_status,
            item.finding_ids,
            item.reason_code,
            item.replacement_requirement,
        )
        if (
            stable(first) != stable(second)
            or first.market_profile != expected["market_profile"]
            or first.result_class.value != expected["result_class"]
            or paths[HistoricalCopyRole.PRIMARY] != expected["primary_path"]
            or paths[HistoricalCopyRole.REPLAY] != expected["replay_path"]
        ):
            raise ValueError(f"v3 runtime-supersession scope mismatch: {logical_result_id}")
    return HistoricalResultRegistry(
        source_commit=str(value["source_commit"]),
        records=records,
        final_holdout_authorized=False,
        profitability_claim_authorized=False,
        registry_schema=RESULT_STATUS_V3_SCHEMA,
        registry_identity=str(declared_identity),
        authority_id=str(value["authority_id"]),
    )


def _load_v4_registry(value: dict[str, Any], payload: bytes) -> HistoricalResultRegistry:
    required_root = {
        "audited_baseline_commit",
        "authority_id",
        "final_holdout_authorized",
        "historical_policy",
        "profitability_claim_authorized",
        "record_count",
        "recorded_at_utc",
        "records",
        "records_identity",
        "registry_identity",
        "schema",
        "source_commit",
    }
    if (
        set(value) != required_root
        or value.get("schema") != RESULT_STATUS_V4_SCHEMA
        or value.get("authority_id") != R2_CLAIM_SCHEMA_SUPERSESSION_AUTHORITY
        or value.get("audited_baseline_commit") != R2_AUDITED_BASELINE_COMMIT
        or not _valid_git_sha(value.get("source_commit"))
        or value.get("historical_policy") != RESULT_STATUS_V2_POLICY
        or value.get("final_holdout_authorized") is not False
        or value.get("profitability_claim_authorized") is not False
    ):
        raise ValueError("v4 historical result registry schema is invalid")
    _utc_timestamp(value.get("recorded_at_utc"))
    raw_records = value.get("records")
    if (
        not isinstance(raw_records, list)
        or not raw_records
        or value.get("record_count") != len(raw_records)
        or value.get("records_identity") != canonical_sha256(raw_records)
    ):
        raise ValueError("v4 historical result registry records identity is invalid")
    material = dict(value)
    declared_identity = material.pop("registry_identity", None)
    if not _valid_sha256(declared_identity) or canonical_sha256(material) != declared_identity:
        raise ValueError("v4 historical result registry root identity is invalid")
    if payload != canonical_json_bytes(value) + b"\n":
        raise ValueError("v4 historical result registry bytes are not canonical")
    records = tuple(_v4_record(raw) for raw in raw_records)
    ordering = tuple(
        sorted(
            records,
            key=lambda item: (item.logical_result_id, item.copy_role.value, item.path),
        ),
    )
    if records != ordering or len({item.path for item in records}) != len(records):
        raise ValueError("v4 historical result records are unordered or duplicated")
    by_logical: dict[str, list[HistoricalResultRecord]] = {}
    for record in records:
        by_logical.setdefault(record.logical_result_id, []).append(record)
    if (
        set(by_logical) != set(R2_CLAIM_SCHEMA_SUPERSEDED_RESULTS)
        or len(records) != 2 * len(R2_CLAIM_SCHEMA_SUPERSEDED_RESULTS)
    ):
        raise ValueError("v4 registry does not cover the exact claim-schema supersession scope")
    for logical_result_id, pair in by_logical.items():
        if (
            {item.copy_role for item in pair}
            != {HistoricalCopyRole.PRIMARY, HistoricalCopyRole.REPLAY}
            or len(pair) != 2
        ):
            raise ValueError(f"v4 primary/replay pair is incomplete: {logical_result_id}")
        expected = R2_CLAIM_SCHEMA_SUPERSEDED_RESULTS[logical_result_id]
        paths = {item.copy_role: item.path for item in pair}
        first, second = pair
        stable = lambda item: (
            item.market_profile,
            item.result_class,
            item.historical_run_status,
            item.financial_result_status,
            item.finding_ids,
            item.reason_code,
            item.replacement_requirement,
        )
        if (
            stable(first) != stable(second)
            or first.market_profile != expected["market_profile"]
            or first.result_class.value != expected["result_class"]
            or paths[HistoricalCopyRole.PRIMARY] != expected["primary_path"]
            or paths[HistoricalCopyRole.REPLAY] != expected["replay_path"]
        ):
            raise ValueError(f"v4 claim-schema supersession scope mismatch: {logical_result_id}")
    return HistoricalResultRegistry(
        source_commit=str(value["source_commit"]),
        records=records,
        final_holdout_authorized=False,
        profitability_claim_authorized=False,
        registry_schema=RESULT_STATUS_V4_SCHEMA,
        registry_identity=str(declared_identity),
        authority_id=str(value["authority_id"]),
    )


def _load_v5_registry(value: dict[str, Any], payload: bytes) -> HistoricalResultRegistry:
    required_root = {
        "audited_baseline_commit",
        "authority_id",
        "final_holdout_authorized",
        "historical_policy",
        "profitability_claim_authorized",
        "record_count",
        "recorded_at_utc",
        "records",
        "records_identity",
        "registry_identity",
        "schema",
        "source_commit",
    }
    if (
        set(value) != required_root
        or value.get("schema") != RESULT_STATUS_V5_SCHEMA
        or value.get("authority_id")
        != R2_REPOSITORY_AUTHORITY_SUPERSESSION_AUTHORITY
        or value.get("audited_baseline_commit") != R2_AUDITED_BASELINE_COMMIT
        or not _valid_git_sha(value.get("source_commit"))
        or value.get("historical_policy") != RESULT_STATUS_V2_POLICY
        or value.get("final_holdout_authorized") is not False
        or value.get("profitability_claim_authorized") is not False
    ):
        raise ValueError("v5 historical result registry schema is invalid")
    _utc_timestamp(value.get("recorded_at_utc"))
    raw_records = value.get("records")
    if (
        not isinstance(raw_records, list)
        or not raw_records
        or value.get("record_count") != len(raw_records)
        or value.get("records_identity") != canonical_sha256(raw_records)
    ):
        raise ValueError("v5 historical result registry records identity is invalid")
    material = dict(value)
    declared_identity = material.pop("registry_identity", None)
    if not _valid_sha256(declared_identity) or canonical_sha256(material) != declared_identity:
        raise ValueError("v5 historical result registry root identity is invalid")
    if payload != canonical_json_bytes(value) + b"\n":
        raise ValueError("v5 historical result registry bytes are not canonical")
    records = tuple(_v5_record(raw) for raw in raw_records)
    ordering = tuple(
        sorted(
            records,
            key=lambda item: (item.logical_result_id, item.copy_role.value, item.path),
        ),
    )
    if records != ordering or len({item.path for item in records}) != len(records):
        raise ValueError("v5 historical result records are unordered or duplicated")
    by_logical: dict[str, list[HistoricalResultRecord]] = {}
    for record in records:
        by_logical.setdefault(record.logical_result_id, []).append(record)
    if (
        set(by_logical) != set(R2_REPOSITORY_AUTHORITY_SUPERSEDED_RESULTS)
        or len(records) != 2 * len(R2_REPOSITORY_AUTHORITY_SUPERSEDED_RESULTS)
    ):
        raise ValueError(
            "v5 registry does not cover the exact repository-authority supersession scope",
        )
    for logical_result_id, pair in by_logical.items():
        if (
            {item.copy_role for item in pair}
            != {HistoricalCopyRole.PRIMARY, HistoricalCopyRole.REPLAY}
            or len(pair) != 2
        ):
            raise ValueError(f"v5 primary/replay pair is incomplete: {logical_result_id}")
        expected = R2_REPOSITORY_AUTHORITY_SUPERSEDED_RESULTS[logical_result_id]
        paths = {item.copy_role: item.path for item in pair}
        first, second = pair
        stable = lambda item: (
            item.market_profile,
            item.result_class,
            item.historical_run_status,
            item.financial_result_status,
            item.finding_ids,
            item.reason_code,
            item.replacement_requirement,
        )
        if (
            stable(first) != stable(second)
            or first.market_profile != expected["market_profile"]
            or first.result_class.value != expected["result_class"]
            or paths[HistoricalCopyRole.PRIMARY] != expected["primary_path"]
            or paths[HistoricalCopyRole.REPLAY] != expected["replay_path"]
        ):
            raise ValueError(
                f"v5 repository-authority supersession scope mismatch: {logical_result_id}",
            )
    return HistoricalResultRegistry(
        source_commit=str(value["source_commit"]),
        records=records,
        final_holdout_authorized=False,
        profitability_claim_authorized=False,
        registry_schema=RESULT_STATUS_V5_SCHEMA,
        registry_identity=str(declared_identity),
        authority_id=str(value["authority_id"]),
    )


def _load_v6_registry(value: dict[str, Any], payload: bytes) -> HistoricalResultRegistry:
    required_root = {
        "audited_baseline_commit",
        "authority_id",
        "final_holdout_authorized",
        "historical_policy",
        "profitability_claim_authorized",
        "record_count",
        "recorded_at_utc",
        "records",
        "records_identity",
        "registry_identity",
        "schema",
        "source_commit",
    }
    if (
        set(value) != required_root
        or value.get("schema") != RESULT_STATUS_V6_SCHEMA
        or value.get("authority_id") != R2_CLAIM_HOLDOUT_SUPERSESSION_AUTHORITY
        or value.get("audited_baseline_commit") != R2_AUDITED_BASELINE_COMMIT
        or not _valid_git_sha(value.get("source_commit"))
        or value.get("historical_policy") != RESULT_STATUS_V2_POLICY
        or value.get("final_holdout_authorized") is not False
        or value.get("profitability_claim_authorized") is not False
    ):
        raise ValueError("v6 historical result registry schema is invalid")
    _utc_timestamp(value.get("recorded_at_utc"))
    raw_records = value.get("records")
    if (
        not isinstance(raw_records, list)
        or not raw_records
        or value.get("record_count") != len(raw_records)
        or value.get("records_identity") != canonical_sha256(raw_records)
    ):
        raise ValueError("v6 historical result registry records identity is invalid")
    material = dict(value)
    declared_identity = material.pop("registry_identity", None)
    if not _valid_sha256(declared_identity) or canonical_sha256(material) != declared_identity:
        raise ValueError("v6 historical result registry root identity is invalid")
    if payload != canonical_json_bytes(value) + b"\n":
        raise ValueError("v6 historical result registry bytes are not canonical")
    records = tuple(_v6_record(raw) for raw in raw_records)
    ordering = tuple(
        sorted(
            records,
            key=lambda item: (item.logical_result_id, item.copy_role.value, item.path),
        ),
    )
    if records != ordering or len({item.path for item in records}) != len(records):
        raise ValueError("v6 historical result records are unordered or duplicated")
    by_logical: dict[str, list[HistoricalResultRecord]] = {}
    for record in records:
        by_logical.setdefault(record.logical_result_id, []).append(record)
    if (
        set(by_logical) != set(R2_CLAIM_HOLDOUT_SUPERSEDED_RESULTS)
        or len(records) != 2 * len(R2_CLAIM_HOLDOUT_SUPERSEDED_RESULTS)
    ):
        raise ValueError("v6 registry does not cover the exact claim/holdout supersession scope")
    for logical_result_id, pair in by_logical.items():
        if (
            {item.copy_role for item in pair}
            != {HistoricalCopyRole.PRIMARY, HistoricalCopyRole.REPLAY}
            or len(pair) != 2
        ):
            raise ValueError(f"v6 primary/replay pair is incomplete: {logical_result_id}")
        expected = R2_CLAIM_HOLDOUT_SUPERSEDED_RESULTS[logical_result_id]
        paths = {item.copy_role: item.path for item in pair}
        first, second = pair
        stable = lambda item: (
            item.market_profile,
            item.result_class,
            item.historical_run_status,
            item.financial_result_status,
            item.finding_ids,
            item.reason_code,
            item.replacement_requirement,
        )
        if (
            stable(first) != stable(second)
            or first.market_profile != expected["market_profile"]
            or first.result_class.value != expected["result_class"]
            or paths[HistoricalCopyRole.PRIMARY] != expected["primary_path"]
            or paths[HistoricalCopyRole.REPLAY] != expected["replay_path"]
        ):
            raise ValueError(f"v6 claim/holdout supersession scope mismatch: {logical_result_id}")
    return HistoricalResultRegistry(
        source_commit=str(value["source_commit"]),
        records=records,
        final_holdout_authorized=False,
        profitability_claim_authorized=False,
        registry_schema=RESULT_STATUS_V6_SCHEMA,
        registry_identity=str(declared_identity),
        authority_id=str(value["authority_id"]),
    )


def _load_v7_registry(value: dict[str, Any], payload: bytes) -> HistoricalResultRegistry:
    required_root = {
        "audited_baseline_commit",
        "authority_id",
        "final_holdout_authorized",
        "historical_policy",
        "profitability_claim_authorized",
        "record_count",
        "recorded_at_utc",
        "records",
        "records_identity",
        "registry_identity",
        "schema",
        "source_commit",
    }
    if (
        set(value) != required_root
        or value.get("schema") != RESULT_STATUS_V7_SCHEMA
        or value.get("authority_id") != R2_ACTIVE_INVENTORY_SUPERSESSION_AUTHORITY
        or value.get("audited_baseline_commit") != R2_AUDITED_BASELINE_COMMIT
        or not _valid_git_sha(value.get("source_commit"))
        or value.get("historical_policy") != RESULT_STATUS_V2_POLICY
        or value.get("final_holdout_authorized") is not False
        or value.get("profitability_claim_authorized") is not False
    ):
        raise ValueError("v7 historical result registry schema is invalid")
    _utc_timestamp(value.get("recorded_at_utc"))
    raw_records = value.get("records")
    if (
        not isinstance(raw_records, list)
        or not raw_records
        or value.get("record_count") != len(raw_records)
        or value.get("records_identity") != canonical_sha256(raw_records)
    ):
        raise ValueError("v7 historical result registry records identity is invalid")
    material = dict(value)
    declared_identity = material.pop("registry_identity", None)
    if not _valid_sha256(declared_identity) or canonical_sha256(material) != declared_identity:
        raise ValueError("v7 historical result registry root identity is invalid")
    if payload != canonical_json_bytes(value) + b"\n":
        raise ValueError("v7 historical result registry bytes are not canonical")
    records = tuple(_v7_record(raw) for raw in raw_records)
    ordering = tuple(
        sorted(
            records,
            key=lambda item: (item.logical_result_id, item.copy_role.value, item.path),
        ),
    )
    if records != ordering or len({item.path for item in records}) != len(records):
        raise ValueError("v7 historical result records are unordered or duplicated")
    by_logical: dict[str, list[HistoricalResultRecord]] = {}
    for record in records:
        by_logical.setdefault(record.logical_result_id, []).append(record)
    if (
        set(by_logical) != set(R2_ACTIVE_INVENTORY_SUPERSEDED_RESULTS)
        or len(records) != 2 * len(R2_ACTIVE_INVENTORY_SUPERSEDED_RESULTS)
    ):
        raise ValueError("v7 registry does not cover the exact active-inventory supersession scope")
    for logical_result_id, pair in by_logical.items():
        if (
            {item.copy_role for item in pair}
            != {HistoricalCopyRole.PRIMARY, HistoricalCopyRole.REPLAY}
            or len(pair) != 2
        ):
            raise ValueError(f"v7 primary/replay pair is incomplete: {logical_result_id}")
        expected = R2_ACTIVE_INVENTORY_SUPERSEDED_RESULTS[logical_result_id]
        paths = {item.copy_role: item.path for item in pair}
        first, second = pair

        def stable(item: HistoricalResultRecord) -> tuple[object, ...]:
            return (
                item.market_profile,
                item.result_class,
                item.historical_run_status,
                item.financial_result_status,
                item.finding_ids,
                item.reason_code,
                item.replacement_requirement,
            )

        if (
            stable(first) != stable(second)
            or first.market_profile != expected["market_profile"]
            or first.result_class.value != expected["result_class"]
            or paths[HistoricalCopyRole.PRIMARY] != expected["primary_path"]
            or paths[HistoricalCopyRole.REPLAY] != expected["replay_path"]
        ):
            raise ValueError(
                f"v7 active-inventory supersession scope mismatch: {logical_result_id}",
            )
    return HistoricalResultRegistry(
        source_commit=str(value["source_commit"]),
        records=records,
        final_holdout_authorized=False,
        profitability_claim_authorized=False,
        registry_schema=RESULT_STATUS_V7_SCHEMA,
        registry_identity=str(declared_identity),
        authority_id=str(value["authority_id"]),
    )


def _load_v8_registry(value: dict[str, Any], payload: bytes) -> HistoricalResultRegistry:
    required_root = {
        "audited_baseline_commit",
        "authority_id",
        "final_holdout_authorized",
        "historical_policy",
        "profitability_claim_authorized",
        "record_count",
        "recorded_at_utc",
        "records",
        "records_identity",
        "registry_identity",
        "schema",
        "source_commit",
    }
    if (
        set(value) != required_root
        or value.get("schema") != RESULT_STATUS_V8_SCHEMA
        or value.get("authority_id") != R2_REPOSITORY_ROOT_SUPERSESSION_AUTHORITY
        or value.get("audited_baseline_commit") != R2_AUDITED_BASELINE_COMMIT
        or not _valid_git_sha(value.get("source_commit"))
        or value.get("historical_policy") != RESULT_STATUS_V2_POLICY
        or value.get("final_holdout_authorized") is not False
        or value.get("profitability_claim_authorized") is not False
    ):
        raise ValueError("v8 historical result registry schema is invalid")
    _utc_timestamp(value.get("recorded_at_utc"))
    raw_records = value.get("records")
    if (
        not isinstance(raw_records, list)
        or not raw_records
        or value.get("record_count") != len(raw_records)
        or value.get("records_identity") != canonical_sha256(raw_records)
    ):
        raise ValueError("v8 historical result registry records identity is invalid")
    material = dict(value)
    declared_identity = material.pop("registry_identity", None)
    if not _valid_sha256(declared_identity) or canonical_sha256(material) != declared_identity:
        raise ValueError("v8 historical result registry root identity is invalid")
    if payload != canonical_json_bytes(value) + b"\n":
        raise ValueError("v8 historical result registry bytes are not canonical")
    records = tuple(_v8_record(raw) for raw in raw_records)
    ordering = tuple(
        sorted(
            records,
            key=lambda item: (item.logical_result_id, item.copy_role.value, item.path),
        ),
    )
    if records != ordering or len({item.path for item in records}) != len(records):
        raise ValueError("v8 historical result records are unordered or duplicated")
    by_logical: dict[str, list[HistoricalResultRecord]] = {}
    for record in records:
        by_logical.setdefault(record.logical_result_id, []).append(record)
    if (
        set(by_logical) != set(R2_REPOSITORY_ROOT_SUPERSEDED_RESULTS)
        or len(records) != 2 * len(R2_REPOSITORY_ROOT_SUPERSEDED_RESULTS)
    ):
        raise ValueError(
            "v8 registry does not cover the exact explicit-repository-root supersession scope",
        )
    for logical_result_id, pair in by_logical.items():
        if (
            {item.copy_role for item in pair}
            != {HistoricalCopyRole.PRIMARY, HistoricalCopyRole.REPLAY}
            or len(pair) != 2
        ):
            raise ValueError(f"v8 primary/replay pair is incomplete: {logical_result_id}")
        expected = R2_REPOSITORY_ROOT_SUPERSEDED_RESULTS[logical_result_id]
        paths = {item.copy_role: item.path for item in pair}
        first, second = pair

        def stable(item: HistoricalResultRecord) -> tuple[object, ...]:
            return (
                item.market_profile,
                item.result_class,
                item.historical_run_status,
                item.financial_result_status,
                item.finding_ids,
                item.reason_code,
                item.replacement_requirement,
            )

        if (
            stable(first) != stable(second)
            or first.market_profile != expected["market_profile"]
            or first.result_class.value != expected["result_class"]
            or paths[HistoricalCopyRole.PRIMARY] != expected["primary_path"]
            or paths[HistoricalCopyRole.REPLAY] != expected["replay_path"]
        ):
            raise ValueError(
                f"v8 explicit-repository-root supersession scope mismatch: {logical_result_id}",
            )
    return HistoricalResultRegistry(
        source_commit=str(value["source_commit"]),
        records=records,
        final_holdout_authorized=False,
        profitability_claim_authorized=False,
        registry_schema=RESULT_STATUS_V8_SCHEMA,
        registry_identity=str(declared_identity),
        authority_id=str(value["authority_id"]),
    )


def load_historical_result_registry(path: Path) -> HistoricalResultRegistry:
    """Parse one immutable additive registry, preserving legacy v1 authority."""

    payload = Path(path).read_bytes()
    value = _strict_json(payload)
    if not isinstance(value, dict):
        raise ValueError("historical result registry must be a JSON object")
    if value.get("schema") == "audit-historical-result-status-v1":
        return _load_v1_registry(value)
    if value.get("schema") == RESULT_STATUS_V2_SCHEMA:
        return _load_v2_registry(value, payload)
    if value.get("schema") == RESULT_STATUS_V3_SCHEMA:
        return _load_v3_registry(value, payload)
    if value.get("schema") == RESULT_STATUS_V4_SCHEMA:
        return _load_v4_registry(value, payload)
    if value.get("schema") == RESULT_STATUS_V5_SCHEMA:
        return _load_v5_registry(value, payload)
    if value.get("schema") == RESULT_STATUS_V6_SCHEMA:
        return _load_v6_registry(value, payload)
    if value.get("schema") == RESULT_STATUS_V7_SCHEMA:
        return _load_v7_registry(value, payload)
    if value.get("schema") == RESULT_STATUS_V8_SCHEMA:
        return _load_v8_registry(value, payload)
    raise ValueError("historical result registry schema is unsupported")


def _hash_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _resolved_run_path(run_directory: Path, repository_root: Path) -> tuple[Path, str]:
    root = require_repository_root(repository_root)
    run = Path(run_directory)
    if run.is_symlink():
        raise ValueError("historical result directory must not be a symlink")
    resolved = run.resolve(strict=True)
    try:
        relative = resolved.relative_to(root).as_posix()
    except ValueError as exc:
        raise ValueError("historical result directory escapes repository root") from exc
    _safe_result_path(relative)
    if not resolved.is_dir():
        raise ValueError("historical result path must be a directory")
    return resolved, relative


def _registry_files(
    root: Path,
    registry_paths: Iterable[Path] | None,
) -> tuple[Path, ...]:
    references = (
        tuple(Path(item) for item in registry_paths)
        if registry_paths is not None
        else tuple(Path(item) for item in DEFAULT_RESULT_STATUS_REFS)
    )
    if not references:
        raise ValueError("at least one required result-status registry must be declared")
    resolved: list[Path] = []
    for reference in references:
        candidate = reference if reference.is_absolute() else root / reference
        if candidate.is_symlink():
            raise ValueError(f"result-status registry must not be a symlink: {candidate}")
        try:
            path = candidate.resolve(strict=True)
            path.relative_to(root)
        except (FileNotFoundError, ValueError) as exc:
            raise ValueError(f"required result-status registry is missing or outside root: {candidate}") from exc
        if not path.is_file():
            raise ValueError(f"required result-status registry is not a file: {path}")
        resolved.append(path)
    if len(set(resolved)) != len(resolved):
        raise ValueError("duplicate result-status registry reference")
    return tuple(resolved)


def _verify_recorded_evidence(run: Path, record: HistoricalResultRecord) -> None:
    for name, expected in record.evidence_hashes.items():
        path = run / name
        if path.is_symlink() or not path.is_file() or _hash_file(path) != expected:
            raise ValueError(f"historical result status evidence binding failed: {record.path}/{name}")


def resolve_result_status(
    run_directory: Path,
    *,
    repository_root: Path,
    registry_paths: Iterable[Path] | None = None,
    verify_recorded_evidence: bool = True,
) -> ResultStatusResolution:
    """Resolve ACTIVE/REVOKED/SUPERSEDED across every required additive registry."""

    root = require_repository_root(repository_root)
    run, relative = _resolved_run_path(run_directory, root)
    matches: list[tuple[HistoricalResultRecord, Path]] = []
    for registry_path in _registry_files(root, registry_paths):
        record = load_historical_result_registry(registry_path).for_path(relative)
        if record is not None:
            matches.append((record, registry_path))
    if len(matches) > 1:
        raise ValueError(f"historical result appears in conflicting registries: {relative}")
    if not matches:
        return ResultStatusResolution(
            relative_path=relative,
            historical_run_status=HistoricalRunStatus.ACTIVE,
            financial_result_status=FinancialResultStatus.ACTIVE,
            record=None,
            registry_path=None,
        )
    record, registry_path = matches[0]
    if (
        record.historical_run_status is HistoricalRunStatus.ACTIVE
        or record.financial_result_status is FinancialResultStatus.ACTIVE
    ):
        raise ValueError("additive historical registries must not contain ACTIVE records")
    if verify_recorded_evidence:
        _verify_recorded_evidence(run, record)
    return ResultStatusResolution(
        relative_path=relative,
        historical_run_status=record.historical_run_status,
        financial_result_status=record.financial_result_status,
        record=record,
        registry_path=registry_path.relative_to(root).as_posix(),
    )


def require_active_result(
    run_directory: Path,
    *,
    repository_root: Path,
    registry_paths: Iterable[Path] | None = None,
) -> ResultStatusResolution:
    """Return only an independently resolved ACTIVE result; reject every other state."""

    resolution = resolve_result_status(
        run_directory,
        repository_root=repository_root,
        registry_paths=registry_paths,
    )
    if not resolution.is_active:
        raise ResultNotActiveError(resolution)
    return resolution


def revoked_result_for_directory(
    run_directory: Path,
    *,
    repository_root: Path,
    registry_path: Path | None = None,
) -> HistoricalResultRecord | None:
    """Backward-compatible lookup; returns any non-ACTIVE record, including SUPERSEDED."""

    resolution = resolve_result_status(
        run_directory,
        repository_root=repository_root,
        registry_paths=(registry_path,) if registry_path is not None else None,
    )
    return resolution.record


def build_historical_result_record_v2(
    run_directory: Path,
    *,
    repository_root: Path,
    logical_result_id: str,
    market_profile: str,
    result_class: HistoricalResultClass,
    copy_role: HistoricalCopyRole,
) -> dict[str, Any]:
    """Build one canonical record from immutable bytes without writing a registry."""

    run, relative = _resolved_run_path(run_directory, repository_root)
    evidence_hashes: dict[str, str] = {}
    for name in V2_EVIDENCE_FILES:
        path = run / name
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"required historical evidence file is missing: {relative}/{name}")
        evidence_hashes[name] = _hash_file(path)
    if result_class is HistoricalResultClass.CANDIDATE:
        status_values = {
            "historical_run_status": HistoricalRunStatus.REVOKED.value,
            "financial_result_status": FinancialResultStatus.INVALIDATED.value,
            "finding_ids": ["R2-001", "R2-002"],
            "reason_code": HistoricalStatusReason.WARMUP_SCORING_ELIGIBILITY_VIOLATION.value,
            "replacement_requirement": (
                ReplacementRequirement.WARMUP_SCORING_FIX_AND_V2_REBUILD.value
            ),
        }
    elif result_class is HistoricalResultClass.BENCHMARK:
        status_values = {
            "historical_run_status": HistoricalRunStatus.SUPERSEDED.value,
            "financial_result_status": FinancialResultStatus.SUPERSEDED.value,
            "finding_ids": ["R2-002"],
            "reason_code": HistoricalStatusReason.RESULT_CONTRACT_V2_SUPERSESSION.value,
            "replacement_requirement": (
                ReplacementRequirement.DATASET_RELEASE_CHECKER_RESULT_SCHEMA_V2_REBUILD.value
            ),
        }
    else:
        raise ValueError("v2 helper supports only Candidate or Benchmark results")
    record = {
        "path": relative,
        "logical_result_id": logical_result_id,
        "market_profile": market_profile,
        "result_class": result_class.value,
        "copy_role": copy_role.value,
        **status_values,
        "historical_bytes_preserved": True,
        "evidence_hashes": evidence_hashes,
    }
    _v2_record(record)
    return record


def build_historical_result_registry_v2(
    records: Iterable[dict[str, Any]],
    *,
    authority_id: str,
    audited_baseline_commit: str,
    source_commit: str,
    recorded_at_utc: datetime,
) -> bytes:
    """Return canonical immutable registry bytes; this helper performs no write."""

    if recorded_at_utc.tzinfo is None or recorded_at_utc.utcoffset() != UTC.utcoffset(recorded_at_utc):
        raise ValueError("recorded_at_utc must use timezone-aware UTC")
    copied = json.loads(canonical_json_bytes(list(records)))
    copied.sort(
        key=lambda item: (
            str(item.get("logical_result_id")),
            str(item.get("copy_role")),
            str(item.get("path")),
        ),
    )
    manifest: dict[str, Any] = {
        "schema": RESULT_STATUS_V2_SCHEMA,
        "authority_id": authority_id,
        "audited_baseline_commit": audited_baseline_commit,
        "source_commit": source_commit,
        "recorded_at_utc": recorded_at_utc.isoformat().replace("+00:00", "Z"),
        "historical_policy": RESULT_STATUS_V2_POLICY,
        "final_holdout_authorized": False,
        "profitability_claim_authorized": False,
        "record_count": len(copied),
        "records": copied,
        "records_identity": canonical_sha256(copied),
    }
    manifest["registry_identity"] = canonical_sha256(manifest)
    payload = canonical_json_bytes(manifest) + b"\n"
    _load_v2_registry(manifest, payload)
    return payload


def build_runtime_supersession_record_v3(
    run_directory: Path,
    *,
    repository_root: Path,
    logical_result_id: str,
    market_profile: str,
    result_class: HistoricalResultClass,
    copy_role: HistoricalCopyRole,
) -> dict[str, Any]:
    """Bind one immutable current-schema Run as runtime-superseded evidence."""

    run, relative = _resolved_run_path(run_directory, repository_root)
    evidence_hashes: dict[str, str] = {}
    for name in V3_EVIDENCE_FILES:
        path = run / name
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"required historical evidence file is missing: {relative}/{name}")
        evidence_hashes[name] = _hash_file(path)
    record = {
        "path": relative,
        "logical_result_id": logical_result_id,
        "market_profile": market_profile,
        "result_class": result_class.value,
        "copy_role": copy_role.value,
        "historical_run_status": HistoricalRunStatus.SUPERSEDED.value,
        "financial_result_status": FinancialResultStatus.SUPERSEDED.value,
        "finding_ids": ["R2-002", "R2-007"],
        "reason_code": HistoricalStatusReason.RUNTIME_AUTHORITY_SUPERSESSION.value,
        "replacement_requirement": ReplacementRequirement.FINAL_PRODUCT_RUNTIME_REBUILD.value,
        "historical_bytes_preserved": True,
        "evidence_hashes": evidence_hashes,
    }
    _v3_record(record)
    return record


def build_runtime_supersession_registry_v3(
    records: Iterable[dict[str, Any]],
    *,
    authority_id: str,
    audited_baseline_commit: str,
    source_commit: str,
    recorded_at_utc: datetime,
) -> bytes:
    """Return the canonical closed R2 runtime-supersession registry bytes."""

    if recorded_at_utc.tzinfo is None or recorded_at_utc.utcoffset() != UTC.utcoffset(
        recorded_at_utc,
    ):
        raise ValueError("recorded_at_utc must use timezone-aware UTC")
    copied = json.loads(canonical_json_bytes(list(records)))
    copied.sort(
        key=lambda item: (
            str(item.get("logical_result_id")),
            str(item.get("copy_role")),
            str(item.get("path")),
        ),
    )
    manifest: dict[str, Any] = {
        "schema": RESULT_STATUS_V3_SCHEMA,
        "authority_id": authority_id,
        "audited_baseline_commit": audited_baseline_commit,
        "source_commit": source_commit,
        "recorded_at_utc": recorded_at_utc.isoformat().replace("+00:00", "Z"),
        "historical_policy": RESULT_STATUS_V2_POLICY,
        "final_holdout_authorized": False,
        "profitability_claim_authorized": False,
        "record_count": len(copied),
        "records": copied,
        "records_identity": canonical_sha256(copied),
    }
    manifest["registry_identity"] = canonical_sha256(manifest)
    payload = canonical_json_bytes(manifest) + b"\n"
    _load_v3_registry(manifest, payload)
    return payload


def build_claim_schema_supersession_record_v4(
    run_directory: Path,
    *,
    repository_root: Path,
    logical_result_id: str,
    market_profile: str,
    result_class: HistoricalResultClass,
    copy_role: HistoricalCopyRole,
) -> dict[str, Any]:
    """Bind one immutable Run superseded only by its incomplete claim schema."""

    run, relative = _resolved_run_path(run_directory, repository_root)
    evidence_hashes: dict[str, str] = {}
    for name in V4_EVIDENCE_FILES:
        path = run / name
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"required historical evidence file is missing: {relative}/{name}")
        evidence_hashes[name] = _hash_file(path)
    record = {
        "path": relative,
        "logical_result_id": logical_result_id,
        "market_profile": market_profile,
        "result_class": result_class.value,
        "copy_role": copy_role.value,
        "historical_run_status": HistoricalRunStatus.SUPERSEDED.value,
        "financial_result_status": FinancialResultStatus.SUPERSEDED.value,
        "finding_ids": ["R2-002", "R2-011"],
        "reason_code": HistoricalStatusReason.SCIENTIFIC_LIMITATION_SCHEMA_SUPERSESSION.value,
        "replacement_requirement": (
            ReplacementRequirement.SCIENTIFIC_LIMITATION_SCHEMA_FIX_AND_REBUILD.value
        ),
        "historical_bytes_preserved": True,
        "evidence_hashes": evidence_hashes,
    }
    _v4_record(record)
    return record


def build_claim_schema_supersession_registry_v4(
    records: Iterable[dict[str, Any]],
    *,
    authority_id: str,
    audited_baseline_commit: str,
    source_commit: str,
    recorded_at_utc: datetime,
) -> bytes:
    """Return canonical closed R2 scientific-claim supersession registry bytes."""

    if recorded_at_utc.tzinfo is None or recorded_at_utc.utcoffset() != UTC.utcoffset(
        recorded_at_utc,
    ):
        raise ValueError("recorded_at_utc must use timezone-aware UTC")
    copied = json.loads(canonical_json_bytes(list(records)))
    copied.sort(
        key=lambda item: (
            str(item.get("logical_result_id")),
            str(item.get("copy_role")),
            str(item.get("path")),
        ),
    )
    manifest: dict[str, Any] = {
        "schema": RESULT_STATUS_V4_SCHEMA,
        "authority_id": authority_id,
        "audited_baseline_commit": audited_baseline_commit,
        "source_commit": source_commit,
        "recorded_at_utc": recorded_at_utc.isoformat().replace("+00:00", "Z"),
        "historical_policy": RESULT_STATUS_V2_POLICY,
        "final_holdout_authorized": False,
        "profitability_claim_authorized": False,
        "record_count": len(copied),
        "records": copied,
        "records_identity": canonical_sha256(copied),
    }
    manifest["registry_identity"] = canonical_sha256(manifest)
    payload = canonical_json_bytes(manifest) + b"\n"
    _load_v4_registry(manifest, payload)
    return payload


def build_repository_authority_supersession_record_v5(
    run_directory: Path,
    *,
    repository_root: Path,
    logical_result_id: str,
    market_profile: str,
    result_class: HistoricalResultClass,
    copy_role: HistoricalCopyRole,
) -> dict[str, Any]:
    """Bind one immutable Run superseded by the explicit-root Product interface."""

    run, relative = _resolved_run_path(run_directory, repository_root)
    evidence_hashes: dict[str, str] = {}
    for name in V5_EVIDENCE_FILES:
        path = run / name
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"required historical evidence file is missing: {relative}/{name}")
        evidence_hashes[name] = _hash_file(path)
    record = {
        "path": relative,
        "logical_result_id": logical_result_id,
        "market_profile": market_profile,
        "result_class": result_class.value,
        "copy_role": copy_role.value,
        "historical_run_status": HistoricalRunStatus.SUPERSEDED.value,
        "financial_result_status": FinancialResultStatus.SUPERSEDED.value,
        "finding_ids": ["R2-002", "R2-007"],
        "reason_code": HistoricalStatusReason.RUNTIME_AUTHORITY_SUPERSESSION.value,
        "replacement_requirement": ReplacementRequirement.FINAL_PRODUCT_RUNTIME_REBUILD.value,
        "historical_bytes_preserved": True,
        "evidence_hashes": evidence_hashes,
    }
    _v5_record(record)
    return record


def build_repository_authority_supersession_registry_v5(
    records: Iterable[dict[str, Any]],
    *,
    authority_id: str,
    audited_baseline_commit: str,
    source_commit: str,
    recorded_at_utc: datetime,
) -> bytes:
    """Return the canonical closed retry-009 repository-authority registry."""

    if recorded_at_utc.tzinfo is None or recorded_at_utc.utcoffset() != UTC.utcoffset(
        recorded_at_utc,
    ):
        raise ValueError("recorded_at_utc must use timezone-aware UTC")
    copied = json.loads(canonical_json_bytes(list(records)))
    copied.sort(
        key=lambda item: (
            str(item.get("logical_result_id")),
            str(item.get("copy_role")),
            str(item.get("path")),
        ),
    )
    manifest: dict[str, Any] = {
        "schema": RESULT_STATUS_V5_SCHEMA,
        "authority_id": authority_id,
        "audited_baseline_commit": audited_baseline_commit,
        "source_commit": source_commit,
        "recorded_at_utc": recorded_at_utc.isoformat().replace("+00:00", "Z"),
        "historical_policy": RESULT_STATUS_V2_POLICY,
        "final_holdout_authorized": False,
        "profitability_claim_authorized": False,
        "record_count": len(copied),
        "records": copied,
        "records_identity": canonical_sha256(copied),
    }
    manifest["registry_identity"] = canonical_sha256(manifest)
    payload = canonical_json_bytes(manifest) + b"\n"
    _load_v5_registry(manifest, payload)
    return payload


def build_claim_holdout_supersession_record_v6(
    run_directory: Path,
    *,
    repository_root: Path,
    logical_result_id: str,
    market_profile: str,
    result_class: HistoricalResultClass,
    copy_role: HistoricalCopyRole,
) -> dict[str, Any]:
    """Bind one immutable Run superseded by corrected claim/Holdout semantics."""

    run, relative = _resolved_run_path(run_directory, repository_root)
    evidence_hashes: dict[str, str] = {}
    for name in V6_EVIDENCE_FILES:
        path = run / name
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"required historical evidence file is missing: {relative}/{name}")
        evidence_hashes[name] = _hash_file(path)
    record = {
        "path": relative,
        "logical_result_id": logical_result_id,
        "market_profile": market_profile,
        "result_class": result_class.value,
        "copy_role": copy_role.value,
        "historical_run_status": HistoricalRunStatus.SUPERSEDED.value,
        "financial_result_status": FinancialResultStatus.SUPERSEDED.value,
        "finding_ids": ["R2-002", "R2-011"],
        "reason_code": HistoricalStatusReason.CLAIM_HOLDOUT_SEMANTIC_SUPERSESSION.value,
        "replacement_requirement": (
            ReplacementRequirement.CLAIM_HOLDOUT_SEMANTIC_FIX_AND_REBUILD.value
        ),
        "historical_bytes_preserved": True,
        "evidence_hashes": evidence_hashes,
    }
    _v6_record(record)
    return record


def build_claim_holdout_supersession_registry_v6(
    records: Iterable[dict[str, Any]],
    *,
    authority_id: str,
    audited_baseline_commit: str,
    source_commit: str,
    recorded_at_utc: datetime,
) -> bytes:
    """Return the canonical closed partial retry-010 supersession registry."""

    if recorded_at_utc.tzinfo is None or recorded_at_utc.utcoffset() != UTC.utcoffset(
        recorded_at_utc,
    ):
        raise ValueError("recorded_at_utc must use timezone-aware UTC")
    copied = json.loads(canonical_json_bytes(list(records)))
    copied.sort(
        key=lambda item: (
            str(item.get("logical_result_id")),
            str(item.get("copy_role")),
            str(item.get("path")),
        ),
    )
    manifest: dict[str, Any] = {
        "schema": RESULT_STATUS_V6_SCHEMA,
        "authority_id": authority_id,
        "audited_baseline_commit": audited_baseline_commit,
        "source_commit": source_commit,
        "recorded_at_utc": recorded_at_utc.isoformat().replace("+00:00", "Z"),
        "historical_policy": RESULT_STATUS_V2_POLICY,
        "final_holdout_authorized": False,
        "profitability_claim_authorized": False,
        "record_count": len(copied),
        "records": copied,
        "records_identity": canonical_sha256(copied),
    }
    manifest["registry_identity"] = canonical_sha256(manifest)
    payload = canonical_json_bytes(manifest) + b"\n"
    _load_v6_registry(manifest, payload)
    return payload


def build_active_inventory_supersession_record_v7(
    run_directory: Path,
    *,
    repository_root: Path,
    logical_result_id: str,
    market_profile: str,
    result_class: HistoricalResultClass,
    copy_role: HistoricalCopyRole,
) -> dict[str, Any]:
    """Bind one immutable retry-011 Run superseded by the official active inventory."""

    run, relative = _resolved_run_path(run_directory, repository_root)
    evidence_hashes: dict[str, str] = {}
    for name in V7_EVIDENCE_FILES:
        path = run / name
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"required historical evidence file is missing: {relative}/{name}")
        evidence_hashes[name] = _hash_file(path)
    record = {
        "path": relative,
        "logical_result_id": logical_result_id,
        "market_profile": market_profile,
        "result_class": result_class.value,
        "copy_role": copy_role.value,
        "historical_run_status": HistoricalRunStatus.SUPERSEDED.value,
        "financial_result_status": FinancialResultStatus.SUPERSEDED.value,
        "finding_ids": ["R2-002"],
        "reason_code": HistoricalStatusReason.OFFICIAL_ACTIVE_INVENTORY_SUPERSESSION.value,
        "replacement_requirement": (
            ReplacementRequirement.OFFICIAL_ACTIVE_INVENTORY_REBUILD.value
        ),
        "historical_bytes_preserved": True,
        "evidence_hashes": evidence_hashes,
    }
    _v7_record(record)
    return record


def build_active_inventory_supersession_registry_v7(
    records: Iterable[dict[str, Any]],
    *,
    authority_id: str,
    audited_baseline_commit: str,
    source_commit: str,
    recorded_at_utc: datetime,
) -> bytes:
    """Return the canonical closed retry-011 active-inventory registry."""

    if recorded_at_utc.tzinfo is None or recorded_at_utc.utcoffset() != UTC.utcoffset(
        recorded_at_utc,
    ):
        raise ValueError("recorded_at_utc must use timezone-aware UTC")
    copied = json.loads(canonical_json_bytes(list(records)))
    copied.sort(
        key=lambda item: (
            str(item.get("logical_result_id")),
            str(item.get("copy_role")),
            str(item.get("path")),
        ),
    )
    manifest: dict[str, Any] = {
        "schema": RESULT_STATUS_V7_SCHEMA,
        "authority_id": authority_id,
        "audited_baseline_commit": audited_baseline_commit,
        "source_commit": source_commit,
        "recorded_at_utc": recorded_at_utc.isoformat().replace("+00:00", "Z"),
        "historical_policy": RESULT_STATUS_V2_POLICY,
        "final_holdout_authorized": False,
        "profitability_claim_authorized": False,
        "record_count": len(copied),
        "records": copied,
        "records_identity": canonical_sha256(copied),
    }
    manifest["registry_identity"] = canonical_sha256(manifest)
    payload = canonical_json_bytes(manifest) + b"\n"
    _load_v7_registry(manifest, payload)
    return payload


def build_repository_root_supersession_record_v8(
    run_directory: Path,
    *,
    repository_root: Path,
    logical_result_id: str,
    market_profile: str,
    result_class: HistoricalResultClass,
    copy_role: HistoricalCopyRole,
) -> dict[str, Any]:
    """Bind one immutable pre-closure Run superseded by the explicit-root fix."""

    run, relative = _resolved_run_path(run_directory, repository_root)
    evidence_hashes: dict[str, str] = {}
    for name in V8_EVIDENCE_FILES:
        path = run / name
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"required historical evidence file is missing: {relative}/{name}")
        evidence_hashes[name] = _hash_file(path)
    record = {
        "path": relative,
        "logical_result_id": logical_result_id,
        "market_profile": market_profile,
        "result_class": result_class.value,
        "copy_role": copy_role.value,
        "historical_run_status": HistoricalRunStatus.SUPERSEDED.value,
        "financial_result_status": FinancialResultStatus.SUPERSEDED.value,
        "finding_ids": ["R2-002", "R2-007"],
        "reason_code": HistoricalStatusReason.EXPLICIT_REPOSITORY_ROOT_SUPERSESSION.value,
        "replacement_requirement": (
            ReplacementRequirement.EXPLICIT_REPOSITORY_ROOT_FIX_AND_REBUILD.value
        ),
        "historical_bytes_preserved": True,
        "evidence_hashes": evidence_hashes,
    }
    _v8_record(record)
    return record


def build_repository_root_supersession_registry_v8(
    records: Iterable[dict[str, Any]],
    *,
    authority_id: str,
    audited_baseline_commit: str,
    source_commit: str,
    recorded_at_utc: datetime,
) -> bytes:
    """Return the canonical closed pre-closure explicit-root registry."""

    if recorded_at_utc.tzinfo is None or recorded_at_utc.utcoffset() != UTC.utcoffset(
        recorded_at_utc,
    ):
        raise ValueError("recorded_at_utc must use timezone-aware UTC")
    copied = json.loads(canonical_json_bytes(list(records)))
    copied.sort(
        key=lambda item: (
            str(item.get("logical_result_id")),
            str(item.get("copy_role")),
            str(item.get("path")),
        ),
    )
    manifest: dict[str, Any] = {
        "schema": RESULT_STATUS_V8_SCHEMA,
        "authority_id": authority_id,
        "audited_baseline_commit": audited_baseline_commit,
        "source_commit": source_commit,
        "recorded_at_utc": recorded_at_utc.isoformat().replace("+00:00", "Z"),
        "historical_policy": RESULT_STATUS_V2_POLICY,
        "final_holdout_authorized": False,
        "profitability_claim_authorized": False,
        "record_count": len(copied),
        "records": copied,
        "records_identity": canonical_sha256(copied),
    }
    manifest["registry_identity"] = canonical_sha256(manifest)
    payload = canonical_json_bytes(manifest) + b"\n"
    _load_v8_registry(manifest, payload)
    return payload


__all__ = [
    "DEFAULT_RESULT_STATUS_REFS",
    "FinancialResultStatus",
    "HistoricalCopyRole",
    "HistoricalResultClass",
    "HistoricalResultRecord",
    "HistoricalResultRegistry",
    "HistoricalRunStatus",
    "HistoricalStatusReason",
    "ReplacementRequirement",
    "R2_AUDITED_BASELINE_COMMIT",
    "R2_CLAIM_SCHEMA_SUPERSEDED_RESULTS",
    "R2_CLAIM_SCHEMA_SUPERSESSION_AUTHORITY",
    "R2_CLAIM_HOLDOUT_SUPERSEDED_RESULTS",
    "R2_CLAIM_HOLDOUT_SUPERSESSION_AUTHORITY",
    "R2_EXPECTED_HISTORICAL_RESULTS",
    "R2_RESULT_STATUS_AUTHORITY",
    "R2_REPOSITORY_AUTHORITY_SUPERSEDED_RESULTS",
    "R2_REPOSITORY_AUTHORITY_SUPERSESSION_AUTHORITY",
    "R2_ACTIVE_INVENTORY_SUPERSEDED_RESULTS",
    "R2_ACTIVE_INVENTORY_SUPERSESSION_AUTHORITY",
    "R2_REPOSITORY_ROOT_SUPERSEDED_RESULTS",
    "R2_REPOSITORY_ROOT_SUPERSESSION_AUTHORITY",
    "R2_RUNTIME_SUPERSEDED_RESULTS",
    "R2_RUNTIME_SUPERSESSION_AUTHORITY",
    "ResultNotActiveError",
    "ResultStatusResolution",
    "build_historical_result_record_v2",
    "build_historical_result_registry_v2",
    "build_claim_holdout_supersession_record_v6",
    "build_claim_holdout_supersession_registry_v6",
    "build_claim_schema_supersession_record_v4",
    "build_claim_schema_supersession_registry_v4",
    "build_repository_authority_supersession_record_v5",
    "build_repository_authority_supersession_registry_v5",
    "build_active_inventory_supersession_record_v7",
    "build_active_inventory_supersession_registry_v7",
    "build_repository_root_supersession_record_v8",
    "build_repository_root_supersession_registry_v8",
    "build_runtime_supersession_record_v3",
    "build_runtime_supersession_registry_v3",
    "load_historical_result_registry",
    "require_active_result",
    "resolve_result_status",
    "revoked_result_for_directory",
]
